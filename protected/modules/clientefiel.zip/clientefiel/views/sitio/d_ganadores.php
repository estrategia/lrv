<div class="contenedor-flex sombra seccion-ganadores">

  <div class="owl-carousel-premios owl-theme">
      <div class="item">
        <div data-role="boton-ganadores" class="btn btn-flat active" data-id="1">Cuidado personal 2018</div>
      </div>
      <div class="item">
        <div data-role="boton-ganadores" class="btn btn-flat" data-id="2">Quesos y vinos 2017</div>
      </div>
      <div class="item">
        <div data-role="boton-ganadores" class="btn btn-flat" data-id="3">Mascotas 2017</div>
      </div>
      <div class="item">
        <div data-role="boton-ganadores" class="btn btn-flat" data-id="4">Lorem ipsum 2016</div>
      </div>
      <div class="item">
        <div data-role="boton-ganadores" class="btn btn-flat" data-id="5">Lorem ipsum 2015</div>
      </div>
      <div class="item">
        <div data-role="boton-ganadores" class="btn btn-flat" data-id="6">Lorem ipsum 2014</div>
      </div>
      <div class="item">
        <div data-role="boton-ganadores" class="btn btn-flat" data-id="7">Lorem ipsum 2013</div>
      </div>
      <div class="item">
        <div data-role="boton-ganadores" class="btn btn-flat" data-id="8">Lorem ipsum 2012</div>
      </div>
      <div class="item">
        <div data-role="boton-ganadores" class="btn btn-flat" data-id="9">Lorem ipsum 2011</div>
      </div>
  </div>

  <table class="table table-striped" data-role="tabla-ganadores" data-id="1">
   <thead>
     <tr>
       <th>Posición</th>
       <th>Votos</th>
       <th>Datos del ganador</th>
     </tr>
   </thead>
   <tbody>
     <tr>
       <td>1</td>
       <td>26.897</td>
       <td>Andrés Felipe Patiño</td>
     </tr>
     <tr>
       <td>2</td>
       <td>26.897</td>
       <td>Juan Sebastián Velasquez</td>
     </tr>
     <tr>
       <td>3</td>
       <td>26.897</td>
       <td>Miguel Sanchez</td>
     </tr>
     <tr>
       <td>4</td>
       <td>26.897</td>
       <td>Andrés Felipe Patiño</td>
     </tr>
     <tr>
       <td>5</td>
       <td>26.897</td>
       <td>Juan Sebastián Velasquez</td>
     </tr>
     <tr>
       <td>6</td>
       <td>26.897</td>
       <td>Miguel Sanchez</td>
     </tr>
   </tbody>
 </table>

 <table class="table table-striped hidden" data-role="tabla-ganadores" data-id="2">
  <thead>
    <tr>
      <th>Posición</th>
      <th>Votos</th>
      <th>Datos del ganador</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>26.897</td>
      <td>Andréssssssss Felipe Patiño</td>
    </tr>
    <tr>
      <td>2</td>
      <td>26.897</td>
      <td>Juan Sebastián Velasquez</td>
    </tr>
    <tr>
      <td>3</td>
      <td>26.897</td>
      <td>Miguel sssssSanchez</td>
    </tr>
    <tr>
      <td>4</td>
      <td>26.897</td>
      <td>Andrés Felipe Patiño</td>
    </tr>
    <tr>
      <td>5</td>
      <td>26.897</td>
      <td>Juan Sebastián Velasquez</td>
    </tr>
    <tr>
      <td>6</td>
      <td>26.897</td>
      <td>Miguel Sanchez</td>
    </tr>
  </tbody>
</table>


<table class="table table-striped hidden" data-role="tabla-ganadores" data-id="3">
 <thead>
   <tr>
     <th>Posición</th>
     <th>Votos</th>
     <th>Datos del ganador</th>
   </tr>
 </thead>
 <tbody>
   <tr>
     <td>1</td>
     <td>26.897</td>
     <td>Andréssssssss Felipe Patiño</td>
   </tr>
   <tr>
     <td>2</td>
     <td>26.897</td>
     <td>Juan Sebastián Velasquez</td>
   </tr>
   <tr>
     <td>3</td>
     <td>26.897</td>
     <td>Miguel sssssSanchez</td>
   </tr>
   <tr>
     <td>4</td>
     <td>26.897</td>
     <td>Andrésff Felipe Patiño</td>
   </tr>
   <tr>
     <td>5</td>
     <td>26.897</td>
     <td>Juansss Sebastián Velasquez</td>
   </tr>
   <tr>
     <td>6</td>
     <td>26.897</td>
     <td>Miguelaaa Sanchez</td>
   </tr>
 </tbody>
</table>

</div>
