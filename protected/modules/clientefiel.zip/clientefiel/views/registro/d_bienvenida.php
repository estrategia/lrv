<div class="contenedor-flex">
  <div class="mensaje-bienvenida">
    <img class="img img-responsive" src="<?php echo Yii::app()->request->baseUrl; ?>/images/clientefiel/bienvenida.png" alt="">
    <div class="btn btn-primary btn-lg"><a href="#">Ahorra y compra</a></div>
  </div>
</div>
