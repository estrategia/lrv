<div class="contenedor-flex">
  <div class="mensaje-bienvenida">
    <img class="img img-responsive" src="<?php echo Yii::app()->request->baseUrl; ?>/images/clientefiel/bienvenida.png" alt="">
    <a href="<?php echo Yii::app()->createUrl('index') ?>">Ahorra y compra</a>
  </div>
</div>
