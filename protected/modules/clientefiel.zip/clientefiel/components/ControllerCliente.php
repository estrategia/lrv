<?php

/**
 * Controller is the customized base controller class.
 * All controller classes for this application should extend from this base class.
 */
class ControllerCliente extends Controller {

    public $menuActivo = 'index';

    public function init() {
       parent::init();
    }


}
