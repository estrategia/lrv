<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"

$hostname_cnn_coopcarvajal = "localhost";
$database_cnn_coopcarvajal = "promarca_tmp_demo";
$username_cnn_coopcarvajal = "promarca_tmp";
$password_cnn_coopcarvajal = "T3mp0r4l";
/*
$hostname_cnn_coopcarvajal = "localhost";
$database_cnn_coopcarvajal = "db_coopcarvajal_demo";
$username_cnn_coopcarvajal = "root";
$password_cnn_coopcarvajal = "admin";
*/
$cnn_coopcarvajal = mysql_connect($hostname_cnn_coopcarvajal, $username_cnn_coopcarvajal, $password_cnn_coopcarvajal) or trigger_error(mysql_error(),E_USER_ERROR); 
date_default_timezone_set('America/Bogota');
?>