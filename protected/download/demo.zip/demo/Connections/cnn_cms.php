<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_cnn_cms = "localhost";
$database_cnn_cms = "elgransa_demo";
$username_cnn_cms = "elgransa_user";
$password_cnn_cms = "4v4nt3l";
$cnn_cms = mysql_connect($hostname_cnn_cms, $username_cnn_cms, $password_cnn_cms) or trigger_error(mysql_error(),E_USER_ERROR); 
?>
