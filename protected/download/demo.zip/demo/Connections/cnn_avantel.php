<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_cnn_avantel = "localhost";
$database_cnn_avantel = "elgransa_demo";
$username_cnn_avantel = "elgransa_user";
$password_cnn_avantel = "4v4nt3l";
$cnn_avantel = mysql_connect($hostname_cnn_avantel, $username_cnn_avantel, $password_cnn_avantel) or trigger_error(mysql_error(),E_USER_ERROR); 
date_default_timezone_set('America/Bogota');
?>
