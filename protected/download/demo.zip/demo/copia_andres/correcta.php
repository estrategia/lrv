<img class="img-responsive lg-coopcarvajal-preguntas" src="<?php echo $base_url; ?>img/lg_coopcarvajal.png" alt="Coopcarvajal - 70 años">
<div class="temario_<?php echo $entrega; ?>">
<?php if ($pregunta_numero==2 || $pregunta_numero==6) {$accion="animo.php?entrega=".$entrega."&siguiente=".$siguiente;} else {$accion="cuestionario.php";} ?>

<form class="preguntas" id="form1_<?php echo $pregunta_numero; ?>" name="form1_<?php echo $pregunta_numero; ?>" method="post" class="ajax" action="../demo/<?php echo $accion; ?>">

 
<p style="text-align:justify"><?php echo $pregunta_numero+1; ?>. <?php  echo utf8_encode($recuperadas[$pregunta_numero]['pregunta']); ?></p>

        <?php  $opcion_correcta=$recuperadas[$pregunta_numero]['respuesta']; ?>
     <p>  <strong>Respuesta Correcta:</strong><br> <?php  echo utf8_encode($recuperadas[$pregunta_numero]['opcion_'.$opcion_correcta.'']); ?></p>
       <input name="siguiente" type="hidden" value="<?php echo $siguiente+1; ?>" />
          <button name="btnForm" style="display: block; margin: 9px auto auto; z-index: 1; position: relative;" type="submit" id="btnForm" class="btn_azul">Continuar</button>
</form>
<?php 
$correcta=strip_tags($_GET['correcta'], '<p><a><small><script>');
if ($correcta=='ok') {
	$claseM="respuesta_correcta";
	$rando=rand(1, 2);
	$img_respuesta="manito_correcto.png";
	switch ($rando) {
		case 1:$mensaje1="Correcto!";$mensaje2="La tienen clara!";
			break;
		
		case 2:$mensaje1="EXCELENTE!!!";$mensaje2="Sigan así!";
			break;
	}
}else{
	$claseM="respuesta_incorrecta";
	$mensaje1="Oppsss!";
	$mensaje2="eligieron la respuesta equivocada";
	$img_respuesta="manito_incorrecto.png";
}
 ?>
 <div class="row gruop_respuesta">
 	<div class="col-sm-7">
		 <div class="<?php echo $claseM; ?>">
			<span><img src="<?php echo $base_url; ?>img/concurso/<?php echo $img_respuesta; ?>" >
			<span><?php echo $mensaje1; ?></span></span>
			<div class="text_respuesta">
			<?php echo $mensaje2; ?>
			</div>
		 </div>
	</div>
	<div class="col-sm-5">
		<div class="silueta silueta_<?php echo $entrega; ?> <?php  echo $correcta; ?>"></div>
	</div>
 </div>

 

</div>
<script type="text/javascript">
  function script_add(){
    $('#ModalConcurso').removeClass('alerta');
    $('#ModalConcurso').addClass('t_pregunta_<?php echo $entrega; ?>');
  }
</script>