<?php 

$puntaje=puntaje_entrega($_SESSION['MM_ID'],$entrega);


?>
<?php if (isset($timeout)): ?>
<div class="time_out">
    <table border="0">
        <tr>
            <td valign="top"  style="padding-left: 10px;">
                <p>
                    <strong>Ooopssss!!!</strong><br>
                    Lo sentimos el tiempo se acabó. Ya completaste las 2 horas<br>
                    Nos vemos en el próximo destino y podrás ganar muchos más puntos.
                </p>
            </td>
            <td valign="top"><img src="<?php echo $base_url; ?>img/concurso/icon_contador.png"></td>
        </tr>
    </table>
</div>
<?php endif ?>
<div class="opcion_puntaje">
<center>
    <img src="img/frutos.png" style="margin-top: 20px; margin-bottom: 20px; max-width: 92%;">
</center>
    <div class="row">
    	<div class="col-sm-5" style="text-align: center;">
        <?php 
        $puntaje_partido = str_split($puntaje) ;
        $puntaje_acumulado_partido=str_split(puntaje_acumulado($_SESSION['MM_ID']));
         ?>
            <strong>Puntaje:<br> 
                <? foreach ($puntaje_partido as $key => $value) { ?>
                    <span style="background-color: #e2007a; border-radius: 5px; color: #fff; display: inline-block; font-size: 50px; font-weight: lighter; margin-top: 5px; padding: 20px 5px;"><?php echo $value;?></span>
                <?php } ?>
            </strong>
        </div>
        <div class="col-sm-7" style="text-align: center;">
            <strong>Puntaje acumulado:<br> 
                <? foreach ($puntaje_acumulado_partido as $key => $value) { ?>
                    <span style="background-color: #e2007a; border-radius: 5px; color: #fff; display: inline-block; font-size: 50px; font-weight: lighter; margin-top: 5px; padding: 20px 5px;"><?php echo $value;?></span>
                <?php } ?>
            </strong>
        </div>
    </div>
</div>
<h2 class="title_familia"><?php echo utf8_encode($_SESSION['MM_Nombre']." ".$_SESSION['MM_Apellidos']); ?></h2>
<p class="mensaje">
<?php 
$super=0;
switch ($entrega) {
	case 1: if (puntaje_entrega($_SESSION['MM_ID'],1)==10000) { $super=1;};  break;
	case 2: if (puntaje_entrega($_SESSION['MM_ID'],2)==20000) { $super=2;};  break;
	case 3: if (puntaje_entrega($_SESSION['MM_ID'],3)==30000) { $super=3;};  break;
	case 4: if (puntaje_entrega($_SESSION['MM_ID'],4)==40000) { $super=4;};  break;	
	}
if ($super==1) {
?>
    <strong>¡Muy buen trabajo!</strong><br>
    <!--Participarán en la rifa del premio para la familia, nos vemos en el siguiente destino-->
<?php } else { ?>
    <strong>¡Gracias por Participar!</strong><br>
     Nos vemos en la siguiente etapa 
<?php } ?>
</p>

<p style="margin-bottom: 0; margin-top: 30px; text-align: right;"><a href="../concurso/introduccion.php" style="margin-bottom: 20px; margin-right: 20px; display: block;" datanamehref="hrefajax"><img src="img/fin.png"></a></p>

<script type="text/javascript">
  function script_add(){
    $('#ModalConcurso').removeClass('alerta');
    $('#ModalConcurso').removeClass('t_pregunta_<?php echo $entrega; ?>');
    $('#ModalConcurso').addClass('t_puntaje');
    $('.temario_top_<?php echo $entrega; ?>').addClass('puntaje_entrega_top').append( "<img class='img-responsive' src='<?php echo $base_url; ?>img/concurso/top_contenedor_blanco.png'>" );
    $('.temario_bottom_<?php echo $entrega; ?>').addClass('puntaje_entrega_bottom').append( "<img class='img-responsive' src='<?php echo $base_url; ?>img/concurso/bottom_contenedor_blanco.png'>" );
    $('.puntaje_entrega_top').removeClass('temario_top_<?php echo $entrega; ?>');
    $('.puntaje_entrega_bottom').removeClass('temario_bottom_<?php echo $entrega; ?>');
  }
  $('#cronometro_parent').remove();
</script>
<?php 
mysql_connect($hostname_cnn_avantel,$username_cnn_avantel,$password_cnn_avantel);
@mysql_select_db($database_cnn_avantel) or die( "Unable to select database");
	$query="TRUNCATE t_resultados;";
mysql_query($query);
mysql_close();
?>
