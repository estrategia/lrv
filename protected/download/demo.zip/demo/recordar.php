<?php
require_once('Connections/cnn_avantel.php');
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_rs_participantes = "-1";
if (isset($_POST['user'])) {
  $colname_rs_participantes = $_POST['user'];
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rs_participantes = sprintf("SELECT * FROM t_participantes WHERE usuario = %s", GetSQLValueString($colname_rs_participantes, "text"));
$rs_participantes = mysql_query($query_rs_participantes, $cnn_avantel) or die(mysql_error());
$row_rs_participantes = mysql_fetch_assoc($rs_participantes);
$totalRows_rs_participantes = mysql_num_rows($rs_participantes);
if (!isset($base_url)) {
  $base_url="/";
}
if (!isset($_POST['recordar'])) {
?>
<div class="modal fade recuperar_contrasena" id="Modalcontrasena" tabindex="-1" role="dialog" aria-labelledby="Contraseña" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          
            <?php include("recordar_inner.php"); ?>
          
      </div>
    </div>
  </div>
</div>
<?php }else if($totalRows_rs_participantes>0){
require_once('../includes/limpiar_post_get.php');
require_once('../app/clases.php');
$configuracion = new sql_query();
$configuracion ->consulta('configuracion', '');
include("../comasy/mailer/PHPMailer/class.phpmailer.php");
    $asunto="Recuperación Clave Tour del Saber";
    $mensaje="
    <p>Solicitud de contraseña:</p>
    <p>
    Nombre completo: ".$row_rs_participantes['nombres']." ".$row_rs_participantes['apellidos']." <br>
    Usuario: ".$row_rs_participantes['usuario']."<br>
    Clave: ".$row_rs_participantes['clave']."
    </p>

    ";
    #remove slashes from content
    $html = stripslashes($mensaje);
    $plain = stripslashes($asunto);
    #initiate PHPMailer class
    $mail = new PHPMailer();
    #set the from e-mail address
    $mail->From = $configuracion->row['correo_contacto'];
    #set the from name
    $mail->FromName = $configuracion->row['nombre_sitio'];
    #set the e-mail type to HTML
    $mail->IsHTML(true);
    $mail->CharSet = 'utf-8';
    #the subject of the email
    $mail->Subject = $asunto;
    #the HTML content of the email
    $mail->Body = $html;
    #the plain text version
    $mail->AltBody = $plain;
    #add subscribers address as the recipient
    $mail->AddAddress($row_rs_participantes['email'],$row_rs_participantes['email_2'],$row_rs_participantes['email_3'],$row_rs_participantes['email_4']);
    #sends the newsletter
    $mail->Send();
    #clears the recipient address
    $mail->ClearAddresses();
    
 ?>
<!-- <img src="<?php echo $base_url; ?>img/concurso/color_autenticacion.png" class="top_login hidden-xs">
<img src="<?php echo $base_url; ?>img/concurso/top_contenedores.png" class="top_login visible-xs img-responsive"> -->
<div class="middle_login">
  <div class="body_recordar">
    <p>
      <strong>Hola <?php echo $row_rs_participantes['nombre_1']; ?> <?php echo $row_rs_participantes['apellido_1']; ?> y Familia, hemos enviado su contraseña a los e-mails referenciados:</strong>
    </p>
    <p class="emails_recordar">
      <?php echo $row_rs_participantes['email']; ?><br>
      <?php echo $row_rs_participantes['email_2']; ?><br>
      xxx@xxx.xxx<br>
      xxx@xxx.xxx
    </p>
    <p align="center"><a data-dismiss="modal" aria-hidden="true" href="#" class=""><img src="img/fin.png"></a></p>
  </div>
  </div>
  
<?php }else{ ?>
<?php include("recordar_inner.php"); ?>
<?php
}
mysql_free_result($rs_participantes);
?>

