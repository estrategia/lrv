<?php 
require_once('Connections/cnn_avantel.php');
if (!isset($base_url)) {
  $base_url="/";
}
if (!isset($_SESSION)) {
  session_start();
}
if (!isset($_SESSION['MM_Username'])) {
  header('Location: login.php');
} 
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE t_participantes SET email_2=%s, email_3=%s, email_4=%s WHERE id_participante=%s",
                       GetSQLValueString($_POST['email_2'], "text"),
                       GetSQLValueString($_POST['email_3'], "text"),
                       GetSQLValueString($_POST['email_4'], "text"),
                       GetSQLValueString($_POST['id_participante'], "int"));

  mysql_select_db($database_cnn_avantel, $cnn_avantel);
  $Result1 = mysql_query($updateSQL, $cnn_avantel) or die(mysql_error());
}

$colname_rsUsuario = "-1";
if (isset($_SESSION['MM_ID'])) {
  $colname_rsUsuario = $_SESSION['MM_ID'];
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsUsuario = sprintf("SELECT * FROM t_participantes WHERE id_participante = %s", GetSQLValueString($colname_rsUsuario, "int"));
$rsUsuario = mysql_query($query_rsUsuario, $cnn_avantel) or die(mysql_error());
$row_rsUsuario = mysql_fetch_assoc($rsUsuario);
$totalRows_rsUsuario = mysql_num_rows($rsUsuario);
?>
<!-- <img src="<?php echo $base_url; ?>img/concurso/color_autenticacion.png" class="top_login hidden-xs"> -->
<!-- <img src="<?php echo $base_url; ?>img/concurso/top_contenedores.png" class="top_login visible-xs img-responsive"> -->
<img src="<?php echo $base_url; ?>img/avantel_logo.png" alt="" class="img-responsive class_01">
<div class="middle_login">
<p style="text-align:right;">
  
  <br>
  <br>
  <img src="<?php echo $base_url; ?>img/datos_personales.png" alt="" class="img-responsive">
</p>
<p class="datos"><strong>Tus datos en nuestro sistema son:</strong></p>
<p>
  Nombre usuario: <?php echo utf8_encode($row_rsUsuario['nombres']); ?></br>
  Apellidos usuario: <?php echo utf8_encode($row_rsUsuario['apellidos']); ?><br>
  Usuario: <?php echo utf8_encode($row_rsUsuario['usuario']); ?><br>
  Contraseña: <?php echo htmlentities($row_rsUsuario['clave'], ENT_COMPAT, ''); ?> <a href="CambiarCon.php" class="CambiarCon pink-site" dataNameHref="hrefajax">Cambiar Contraseña</a><br>
  Ciudad: <?php echo utf8_encode($row_rsUsuario['distrito']); ?><br>
  Área: <?php echo utf8_encode($row_rsUsuario['empresa']); ?><br>
  E-mail: <?php echo utf8_encode($row_rsUsuario['email']); ?>
</p>
<!-- <p class="morado_font">Compártenos 3 e-mails de los integrantes de tu familia, para mantener el contacto:</p> -->
 <form method="post" name="form1" action="datos_participante.php" role="form">
  <!-- <div class="form-group">
    <input type="email" class="form-control" placeholder="E-mail opción 1" name="email_2" value="<?php echo htmlentities($row_rsUsuario['email_2'], ENT_COMPAT, ''); ?>" >
  </div>
  <div class="form-group">
    <input type="email" class="form-control" placeholder="E-mail opción 2" name="email_3" value="<?php echo htmlentities($row_rsUsuario['email_3'], ENT_COMPAT, ''); ?>" >
  </div>
  <div class="form-group">
    <input type="email" class="form-control" placeholder="E-mail opción 3" name="email_4" value="<?php echo htmlentities($row_rsUsuario['email_4'], ENT_COMPAT, ''); ?>" >
  </div> -->
  <div class="form-group">
    <!-- <button  type="submit" class="btn_naranja">Actualizar datos</button> -->
    <div class="space"></div>
    <a dataNameHref="hrefajax" href="logout.php"><img src="img/fin.png"></a>
    <a dataNameHref="hrefajax" href="introduccion.php"><img src="img/jugar.png"></a>
  </div>
  <input type="hidden" name="MM_update" value="form1">
  <input type="hidden" name="id_participante" value="<?php echo $row_rsUsuario['id_participante']; ?>">
</form>
</div>
    <script type="text/javascript">
      function script_add(){
        $('#ModalConcurso').removeClass('login_concurso');
        $('#ModalConcurso').addClass('datos_participante');
      }
    </script>
<?php 
mysql_free_result($rsUsuario);
?>