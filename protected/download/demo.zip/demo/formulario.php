<?php require_once('Connections/cnn_avantel.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE t_resultados SET id_participante=%s, id_pregunta=%s, respuesta=%s, opcion=%s, puntaje=%s, entrega=%s, fecha_respuesta=%s WHERE id_resultado=%s",
                       GetSQLValueString($_POST['id_participante'], "int"),
                       GetSQLValueString($_POST['id_pregunta'], "int"),
                       GetSQLValueString($_POST['respuesta'], "int"),
                       GetSQLValueString($_POST['opcion'], "int"),
                       GetSQLValueString($_POST['puntaje'], "int"),
                       GetSQLValueString($_POST['entrega'], "int"),
                       GetSQLValueString($_POST['fecha_respuesta'], "date"),
                       GetSQLValueString($_POST['id_resultado'], "int"));

  mysql_select_db($database_cnn_avantel, $cnn_avantel);
  $Result1 = mysql_query($updateSQL, $cnn_avantel) or die(mysql_error());
}

$colname_rsEditar = "-1";
if (isset($_GET['id_resultado'])) {
  $colname_rsEditar = $_GET['id_resultado'];
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsEditar = sprintf("SELECT * FROM t_resultados WHERE id_resultado = %s", GetSQLValueString($colname_rsEditar, "int"));
$rsEditar = mysql_query($query_rsEditar, $cnn_avantel) or die(mysql_error());
$row_rsEditar = mysql_fetch_assoc($rsEditar);
$totalRows_rsEditar = mysql_num_rows($rsEditar);
?>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Id_resultado:</td>
      <td><?php echo $row_rsEditar['id_resultado']; ?></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Id_participante:</td>
      <td><input type="text" name="id_participante" value="<?php echo htmlentities($row_rsEditar['id_participante'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Id_pregunta:</td>
      <td><input type="text" name="id_pregunta" value="<?php echo htmlentities($row_rsEditar['id_pregunta'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Respuesta:</td>
      <td><input type="text" name="respuesta" value="<?php echo htmlentities($row_rsEditar['respuesta'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Opcion:</td>
      <td><input type="text" name="opcion" value="<?php echo htmlentities($row_rsEditar['opcion'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Puntaje:</td>
      <td><input type="text" name="puntaje" value="<?php echo htmlentities($row_rsEditar['puntaje'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Entrega:</td>
      <td><input type="text" name="entrega" value="<?php echo htmlentities($row_rsEditar['entrega'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Fecha_respuesta:</td>
      <td><input type="text" name="fecha_respuesta" value="<?php echo htmlentities($row_rsEditar['fecha_respuesta'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Update record" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="id_resultado" value="<?php echo $row_rsEditar['id_resultado']; ?>" />
</form>
<?php
mysql_free_result($rsEditar);
?>
