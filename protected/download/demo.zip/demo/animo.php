<!--
DESPUES DE arrojar la  LA respuesta de la pregunta 3

SI VAN 3000 MILLAS
1.Excelente…Van muy bien, sigan adelante! (Aplica para DEPORTES y para CULTURA)
2.FELICITACIONES. Van por la ruta indicada. En caso de duda exploren en www.carvajal.com 
3.Así se hace! Este destino lo van a ganar. Si tienen dudas pueden explorar www.coopcarvajal.com


SI VAN 2000 MILLAS
1.Ánimo! Recuerden preguntarle a google (Aplica para DEPORTES y para CULTURA)
2.Ánimo!! En la web de Carvajal algunas respuestas pueden encontrar. www.carvajal.com (aplica para NUESTRA EMPRESA)
3. Vamos para adelante!! Explora nuestra web www.coopcarvajal.com Algunas respuestas encontrarás (aplica para MI COOPERATIVA)

SI VAN 1000 O CERO MILLAS
1.Todo puede ser mejor! Ponle más concentración. Pregúntale a Google (aplica para DEPORTES Y CULTURA)
2. Llevan pocas millas. ¡es hora de recuperarse!! En www.Carvajal.com algunas respuestas podrán encontrar
3. Arriba el ánimo. Es hora de ganar. Explora nuestra web www.coopcarvajal.com algunas respuestas encontrarás

-->
<?php

session_start();
include("funciones.php");
$acumulado=puntaje_entrega($_SESSION['MM_ID'],$_GET['entrega']);
$entrega=strip_tags($_GET['entrega'], '<p><a><small><script>');

$positivo=array("Excelente! Van muy bien, sigan adelante!","FELICITACIONES. Van por la ruta indicada","As&iacute; se hace! Este destino lo van a ganar","Continua as&iacute; y llegar&aacute;s a la final");
$negativo=array("Todo puede ser mejor! Ponle m&aacute;s concentraci&oacute;n", "Arriba el &Aacute;nimo. Es hora de ganar.", "No te desanimes.. Hazte fan de nuestra p&aacute;gina en facebook y recibe pistas para ganar", "Recuerda! Para mejorar tu puntaje has clic en el bot&oacute;n: Pistas para ganar");

shuffle($positivo);
shuffle($negativo);

switch ($_GET['entrega']) {
	case 1: if ($acumulado<3000) {$mensaje_animo=$negativo[0];} else {$mensaje_animo=$positivo[0];}; break;
	case 2: if ($acumulado<6000) {$mensaje_animo=$negativo[0];} else {$mensaje_animo=$positivo[0];}; break;
	case 3: if ($acumulado<9000) {$mensaje_animo=$negativo[0];} else {$mensaje_animo=$positivo[0];}; break;
	case 4: if ($acumulado<12000) {$mensaje_animo=$negativo[0];} else {$mensaje_animo=$positivo[0];}; break;
	}

/*
# ENTRE 0 Y 1000 DEPORTES Y CULTURA
if (($acumulado>0 && $acumulado<=1000) && $_GET['entrega']==1) {$mensaje_animo="Todo puede ser mejor! Ponle más concentración. Pregúntale a Google";}
if (($acumulado>0 && $acumulado<=1000) && $_GET['entrega']==3) {$mensaje_animo="Todo puede ser mejor! Ponle más concentración. Pregúntale a Google";}
# ENTRE 0 Y 1000 NUESTRA EMPRESA
if (($acumulado>0 && $acumulado<=1000) && $_GET['entrega']==2) {$mensaje_animo="Llevan pocas millas. ¡es hora de recuperarse!! En www.Carvajal.com algunas respuestas podrán encontrar";}
# ENTRE 0 Y 1000 MI COOPERATIVA
if (($acumulado>0 && $acumulado<=1000) && $_GET['entrega']==4) {$mensaje_animo="Arriba el ánimo. Es hora de ganar. Explora nuestra web www.coopcarvajal.com algunas respuestas encontrarás";}

# ENTRE 1000 Y 2000 DEPORTES Y CULTURA
if (($acumulado>1000 && $acumulado<=2000) && $_GET['entrega']==1) {$mensaje_animo="Ánimo! Recuerden preguntarle a google";}
if (($acumulado>1000 && $acumulado<=2000) && $_GET['entrega']==3) {$mensaje_animo="Ánimo! Recuerden preguntarle a google";}
# ENTRE 1000 Y 2000 NUESTRA EMPRESA
if (($acumulado>1000 && $acumulado<=2000) && $_GET['entrega']==2) {$mensaje_animo="Ánimo!! En la web de Carvajal algunas respuestas pueden encontrar. www.carvajal.com";}
# ENTRE 1000 Y 2000 NUESTRA EMPRESA
if (($acumulado>1000 && $acumulado<=2000) && $_GET['entrega']==4) {$mensaje_animo="Vamos para adelante!! Explora nuestra web www.coopcarvajal.com Algunas respuestas encontrarás";}

# ENTRE 2000 Y 3000 DEPORTES Y CULTURA
if (($acumulado>2000 && $acumulado<=3000) && $_GET['entrega']==1) {$mensaje_animo="Excelente…Van muy bien, sigan adelante! ";}
if (($acumulado>2000 && $acumulado<=3000) && $_GET['entrega']==3) {$mensaje_animo="Excelente…Van muy bien, sigan adelante! ";}
# ENTRE 2000 Y 3000 NUESTRA EMPRESA
if (($acumulado>2000 && $acumulado<=3000) && $_GET['entrega']==2) {$mensaje_animo="FELICITACIONES. Van por la ruta indicada. En caso de duda exploren en www.carvajal.com";}
# ENTRE 2000 Y 3000 NUESTRA EMPRESA
if (($acumulado>2000 && $acumulado<=3000) && $_GET['entrega']==4) {$mensaje_animo="Así se hace! Este destino lo van a ganar. Si tienen dudas pueden explorar www.coopcarvajal.com";}
if ($acumulado>3000) {$mensaje_animo="Bien hecho...sigue participando...";}*/

?>
<form class="preguntas" id="form2" name="form2" method="post" action="../demo/cuestionario.php">
<div class="row">
	<div class="col-sm-4">
		<div class="avatar_animos avartar_<?php echo $entrega; ?>">
		</div>
	</div>
	<div class="col-sm-8">
		<div class="nube_animo">
			
				<?php echo $mensaje_animo;?>
				<input name="siguiente" type="hidden" value="<?php echo $_GET['siguiente']+1; ?>" />     
			
		</div>
	</div>
</div>

<button name="btnForm" style="float: right; margin-top: -31px;" type="submit" id="btnForm" class="btn_naranja" value="Grabar">Continuar</button>
</form>
<script type="text/javascript">
  function script_add(){
    $('#ModalConcurso').removeClass('t_pregunta_<?php echo $entrega; ?>');
    $('#ModalConcurso').addClass('animos');
  }
</script>