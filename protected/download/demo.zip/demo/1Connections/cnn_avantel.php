<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_cnn_avantel = "localhost";
$database_cnn_avantel = "promarca_db_avantel";
$username_cnn_avantel = "promarca_tmp";
$password_cnn_avantel = "T3mp0r4l";
$cnn_avantel = mysql_connect($hostname_cnn_avantel, $username_cnn_avantel, $password_cnn_avantel) or trigger_error(mysql_error(),E_USER_ERROR); 
date_default_timezone_set('America/Bogota');
?>