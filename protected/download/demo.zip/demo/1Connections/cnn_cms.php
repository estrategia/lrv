<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_cnn_cms = "localhost";
$database_cnn_cms = "promarca_db_avantel";
$username_cnn_cms = "promarca_tmp";
$password_cnn_cms = "T3mp0r4l";
$cnn_cms = mysql_connect($hostname_cnn_cms, $username_cnn_cms, $password_cnn_cms) or trigger_error(mysql_error(),E_USER_ERROR); 
?>