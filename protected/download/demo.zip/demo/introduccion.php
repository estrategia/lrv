<?php
if (!isset($base_url)) {
  $base_url="/";
}
 include("temarios.php");?>
 <img src="<?php echo $base_url; ?>img/concurso/top_contenedor_blanco.png" class="top_blanco_general img-responsive visible-xs">
<img class="img-responsive lg-coopcarvajal" src="<?php echo $base_url; ?>img/lg_coopcarvajal.png" alt="Coopcarvajal - 70 años">
 <div class="conte_introduccion">
 	<img src="img/intro_etapa.jpg">
<div class="group_button">

<form action="../demo/cuestionario.php" method="post" name="frmInicio">
<input name="siguiente" type="hidden" value="1">
<button style="background-color: transparent; border: none;"><img src="img/jugar_ya.png"></button>
</form>

<!-- <a href="alerta.php" datanamehref="hrefajax"><img src="img/jugar_ya.png"></a>
<a href="#" datanamehref="hrefajax"><img src="img/jugar_ya.png"></a> -->
<form action="cuestionario.php" method="post" name="frmInicio">
<input name="siguiente" type="hidden" value="1">
<button style="background-color: transparent; border: none;"><img src="img/empieza_a_jugar.png"></button>
</form>
</div>
</div>
 <img src="<?php echo $base_url; ?>img/concurso/bottom_contenedor_blanco.png" class="bottom_blanco_general img-responsive  visible-xs">




<script type="text/javascript">
  function script_add(){
  	$('#ModalConcurso').removeClass('datos_participante');
	$('#ModalConcurso').removeClass('t_puntaje');
    $('#ModalConcurso').addClass('introduccion');
    $('#ModalConcurso').addClass('intro_<?php echo $entrega; ?>');
  }
</script>
