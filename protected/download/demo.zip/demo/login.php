<?php 
require_once('Connections/cnn_avantel.php');
if (!isset($base_url)) {
  $base_url="/";
}
if (!isset($_SESSION)) {
  session_start();
}
if (isset($_SESSION['MM_Username'])) {
  include('datos_participante.php');  
}else{
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['user'])) {
  $loginUsername=$_POST['user'];
  $password=$_POST['password'];
  $MM_fldUserAuthorization = "identificacion";
  $MM_redirectLoginSuccess = "datos_participante.php";
  $MM_redirectLoginFailed = "login.php?error=1";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_cnn_avantel, $cnn_avantel);
  	
  $LoginRS__query=sprintf("SELECT usuario, clave, nombres, apellidos, id_participante FROM t_participantes WHERE usuario=%s AND clave=%s",
  GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $cnn_avantel) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
    
    $loginStrGroup  = mysql_result($LoginRS,0,'nombres');
    $loginID  = mysql_result($LoginRS,0,'id_participante');
    $loginApellidos  = mysql_result($LoginRS,0,'apellidos');
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_Nombre'] = $loginStrGroup;	      
    $_SESSION['MM_ID'] = $loginID;	     	      
    $_SESSION['MM_Apellidos'] = $loginApellidos;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];
    }
    if ($_POST['type']=='inner') {
      ?>
      <script type="text/javascript">
        location.reload();
      </script>
    <?php
    }else{
      header("Location: " . $MM_redirectLoginSuccess );
    }
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<img src="<?php echo $base_url; ?>img/sesion.png" class="top_login hidden-xs">

<div class="middle_login_2">
<!-- <h2 class="saludo">Hola,</h2>
<p class="saludo">Falta poco para iniciar</p> -->
<form action="../demo/login.php" method="post" role="form" id="frmLogin">
    <div class="form-group">
      <span><img src="img/ico-sesion.png"> </span><label for="user">Usuario</label>
      <input name="user" type="text" class="form-control"  id="user" placeholder="Número de Cédula del Afiliado a la Cooperativa">
    </div>
    <div class="form-group">
      <span><img src="img/ico-sesion-2.png"> </span><label for="password">Contraseña</label>
      <input name="password" type="password" class="form-control"  id="password" placeholder="Últimos 4 dígitos número cédula">
      <?php if (isset($_GET['error'])==1) {echo "<p class='error_login'>Credenciales Incorrectas.</p>";} ?>
    </div>
     <span><img src="img/ico-sesion-3.png"> </span><a class="pink-site" data-toggle="modal" href="#Modalcontrasena" id="recuperar">¿Olvidaste tu contraseña?</a>
      <br>
      <br>
      <br>

    <div class="row">
      <div class="col-sm-6 ">
        <img src="<?php echo $base_url; ?>img/avantel_logo.png" alt="" width="148" class="img-responsive">
      </div>
      <div class="col-sm-6 " align="right">
        <?php if (isset($_GET['parametro1']) && $_GET['parametro1']!=''): ?>
          <input type="hidden" name="type" value="inner">
        <?php else: ?>
          <input type="hidden" name="type" value="out">
        <?php endif ?>
        <button style="background-color: transparent; border: none;" type="submit"><img src="<?php echo $base_url ?>img/btn_sesion.png"></button>
      </div>
    </div>
    
    </form>
</div>
<?php if (isset($_GET['cerro'])) { ?>
<script type="text/javascript">
location.reload();
</script>
<?php } ?>
<script type="text/javascript">
  function script_add(){
    $('#ModalConcurso').removeClass('datos_participante');
    $('#ModalConcurso').addClass('login_concurso');
    $('#recuperar').click(function(){
      $('#ModalConcurso').modal('hide');
    });
  }
  
</script>
<?php } ?>
