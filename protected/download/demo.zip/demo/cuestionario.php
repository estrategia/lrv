<?php require_once('Connections/cnn_avantel.php');
if (!isset($base_url)) {
  $base_url="/";
} 
session_start(); 
include("../demo/temarios.php");
?>
<div class="visible-xs temario_top_<?php echo $entrega; ?>"></div>
<div class="middle_preguntas">
	<img style="margin-left: 20px; margin-top: 20px;" src="img/avantel_logo.png">
<?php


include("../demo/cronometro.php");


if ($segundos_restantes<=0) {
	$timeout=true;
	include("../demo/puntaje.php");	
	} else {

/*

 s� no se han seleccionado preguntas se insertan las pregunras
 s� ya se insertaron preguntas para el usuario y la entrega se verifica s� ya respondi� todas las preguntas de la entrega en curso
 	cuando se respondan todas entonces se le muestra mensaje de ya respond�� o la siguiente entrega s� ya es tiempo

*/

# insertar preguntas


if (entrega_participante($_SESSION['MM_ID'],$entrega)==0) { 

foreach ($seleccion as $valor) {

  $insertSQL = sprintf("INSERT INTO t_resultados (id_participante, id_pregunta, respuesta, opcion, puntaje, entrega, fecha_respuesta) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_SESSION['MM_ID'], "int"),
                       GetSQLValueString($valor['id'], "int"),
                       GetSQLValueString($valor['respuesta'], "int"),
                       GetSQLValueString(NULL, "int"),
					   GetSQLValueString($valor['valor'], "int"),
					   GetSQLValueString($entrega, "int"),
                       GetSQLValueString(date('Y-m-d H:i:s'), "date"));

  mysql_select_db($database_cnn_avantel, $cnn_avantel);
  $Result1 = mysql_query($insertSQL, $cnn_avantel) or die(mysql_error());
}
}
?>
<?php 
if (estado_entrega($_SESSION['MM_ID'],$entrega)!=1) {
	include("../demo/puntaje.php");	
	} else {

	$recuperadas=recuperar_preguntas($_SESSION['MM_ID'],$entrega);
?>
<?php 
if (isset($_GET['siguiente'])) {
$siguiente=$_GET['siguiente'];
}else if(isset($_POST['siguiente'])){
$siguiente=$_POST['siguiente'];
}
	switch($siguiente){ 
		case 1: if (isset($_GET['espera'])==1) {$pregunta_numero=0; $siguiente=1; include("../demo/correcta.php");} else {$pregunta_numero=0; $siguiente=1; include("../demo/preguntas.php");}; break;
		case 2: if (isset($_GET['espera'])==1) {$pregunta_numero=0; $siguiente=1; include("../demo/correcta.php");} else {$pregunta_numero=1; $siguiente=2; include("../demo/preguntas.php");}; break;
		case 3: if (isset($_GET['espera'])==1) {$pregunta_numero=1; $siguiente=2; include("../demo/correcta.php");} else {$pregunta_numero=2; $siguiente=3; include("../demo/preguntas.php");}; break;
		case 4: if (isset($_GET['espera'])==1) {$pregunta_numero=2; $siguiente=3; include("../demo/correcta.php");} else {$pregunta_numero=3; $siguiente=4; include("../demo/preguntas.php");}; break;
		case 5: if (isset($_GET['espera'])==1) {$pregunta_numero=3; $siguiente=4; include("../demo/correcta.php");} else {$pregunta_numero=4; $siguiente=5; include("../demo/preguntas.php");}; break;
		case 6: if (isset($_GET['espera'])==1) {$pregunta_numero=4; $siguiente=5; include("../demo/correcta.php");} else {$pregunta_numero=5; $siguiente=6; include("../demo/preguntas.php");}; break;

	}

?>
<?php } ?>
<?php } ?>
</div>
<div class="visible-xs temario_bottom_<?php echo $entrega; ?>"></div>
<script type="text/javascript">
  function script_add(){
  	$('#ModalConcurso').removeClass('introduccion');
  }
</script>