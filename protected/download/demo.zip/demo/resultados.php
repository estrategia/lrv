<?php require_once('Connections/cnn_avantel.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsListado = "SELECT t_participantes.nombres, t_participantes.apellidos, t_participantes.distrito, t_participantes.empresa, t_participantes.email, t_participantes.email_2, t_participantes.email_3, t_participantes.email_4, t_preguntas.id_pregunta, t_preguntas.pregunta, t_preguntas.opcion_1, t_preguntas.opcion_2, t_preguntas.opcion_3, t_preguntas.opcion_4, t_preguntas.puntaje, t_temarios.temario, t_resultados.opcion as respuesta, t_resultados.fecha_respuesta FROM t_resultados INNER JOIN t_participantes ON t_resultados.id_participante = t_participantes.id_participante INNER JOIN t_preguntas ON t_preguntas.id_pregunta = t_resultados.id_pregunta INNER JOIN t_temarios ON t_temarios.id_temario = t_preguntas.id_temario ";
$rsListado = mysql_query($query_rsListado, $cnn_avantel) or die(mysql_error());
$row_rsListado = mysql_fetch_assoc($rsListado);
$totalRows_rsListado = mysql_num_rows($rsListado);

$fecha_actual=date('Y-m-d H_i_s');
include("funciones.php");
header("Content-type: application/vnd.ms-excel");
//indicamos al navegador que se estÃ¡ devolviendo un archivo
header("Content-Disposition: attachment; filename=tour_del_saber_respuestas_".$fecha_actual.".xls");
//con esto evitamos que el navegador lo grabe en su cachÃ©
header("Pragma: no-cache");
header("Expires: 0");
?>
<table border="1">
  <tr>
    <td>nombres</td>
    <td>apellidos</td>
    <td>distrito</td>
    <td>empresa</td>
    <td>email</td>
    <td>email_2</td>
    <td>email_3</td>
    <td>email_4</td>
    <td>id_pregunta</td>
    <td>pregunta</td>
    <td>opcion_1</td>
    <td>opcion_2</td>
    <td>opcion_3</td>
    <td>opcion_4</td>
    <td>puntaje</td>
    <td>temario</td>
    <td>respuesta</td>
    <td>fecha_respuesta</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_rsListado['nombres']; ?></td>
      <td><?php echo $row_rsListado['apellidos']; ?></td>
      <td><?php echo $row_rsListado['distrito']; ?></td>
      <td><?php echo $row_rsListado['empresa']; ?></td>
      <td><?php echo $row_rsListado['email']; ?></td>
      <td><?php echo $row_rsListado['email_2']; ?></td>
      <td><?php echo $row_rsListado['email_3']; ?></td>
      <td><?php echo $row_rsListado['email_4']; ?></td>
      <td><?php echo $row_rsListado['id_pregunta']; ?></td>
      <td><?php echo $row_rsListado['pregunta']; ?></td>
      <td><?php echo $row_rsListado['opcion_1']; ?></td>
      <td><?php echo $row_rsListado['opcion_2']; ?></td>
      <td><?php echo $row_rsListado['opcion_3']; ?></td>
      <td><?php echo $row_rsListado['opcion_4']; ?></td>
      <td><?php echo $row_rsListado['puntaje']; ?></td>
      <td><?php echo $row_rsListado['temario']; ?></td>
      <td><?php echo $row_rsListado['respuesta']; ?></td>
      <td><?php echo $row_rsListado['fecha_respuesta']; ?></td>
    </tr>
    <?php } while ($row_rsListado = mysql_fetch_assoc($rsListado)); ?>
</table>
<?php
mysql_free_result($rsListado);
?>