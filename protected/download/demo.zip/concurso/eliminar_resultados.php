<?php require_once('../Connections/cnn_cms.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_rsUsuario = "-1";
if (isset($_GET['id_participante'])) {
  $colname_rsUsuario = $_GET['id_participante'];
}
mysql_select_db($database_cnn_cms, $cnn_cms);
$query_rsUsuario = sprintf("SELECT * FROM t_participantes WHERE id_participante = %s", GetSQLValueString($colname_rsUsuario, "int"));
$rsUsuario = mysql_query($query_rsUsuario, $cnn_cms) or die(mysql_error());
$row_rsUsuario = mysql_fetch_assoc($rsUsuario);
$totalRows_rsUsuario = mysql_num_rows($rsUsuario);

$colname_rsTemario1 = "-1";
if (isset($_GET['id_participante'])) {
  $colname_rsTemario1 = $_GET['id_participante'];
}
mysql_select_db($database_cnn_cms, $cnn_cms);
$query_rsTemario1 = sprintf("SELECT t_resultados.id_resultado, t_resultados.id_participante, t_resultados.id_pregunta, t_resultados.respuesta, t_resultados.opcion, t_resultados.entrega, t_resultados.fecha_respuesta, t_preguntas.pregunta, t_preguntas.opcion_1, t_preguntas.opcion_2, t_preguntas.opcion_3, t_preguntas.opcion_4, t_preguntas.id_temario, t_preguntas.puntaje FROM t_resultados INNER JOIN t_preguntas ON t_preguntas.id_pregunta = t_resultados.id_pregunta WHERE t_resultados.id_participante = %s AND t_resultados.entrega=1", GetSQLValueString($colname_rsTemario1, "int"));
$rsTemario1 = mysql_query($query_rsTemario1, $cnn_cms) or die(mysql_error());
$row_rsTemario1 = mysql_fetch_assoc($rsTemario1);
$totalRows_rsTemario1 = mysql_num_rows($rsTemario1);

$colname_rsTemario2 = "-1";
if (isset($_GET['id_participante'])) {
  $colname_rsTemario2 = $_GET['id_participante'];
}
mysql_select_db($database_cnn_cms, $cnn_cms);
$query_rsTemario2 = sprintf("SELECT t_resultados.id_resultado, t_resultados.id_participante, t_resultados.id_pregunta, t_resultados.respuesta, t_resultados.opcion, t_resultados.entrega, t_resultados.fecha_respuesta, t_preguntas.pregunta, t_preguntas.opcion_1, t_preguntas.opcion_2, t_preguntas.opcion_3, t_preguntas.opcion_4, t_preguntas.id_temario, t_preguntas.puntaje FROM t_resultados INNER JOIN t_preguntas ON t_preguntas.id_pregunta = t_resultados.id_pregunta WHERE t_resultados.id_participante = %s AND t_resultados.entrega=2", GetSQLValueString($colname_rsTemario2, "int"));
$rsTemario2 = mysql_query($query_rsTemario2, $cnn_cms) or die(mysql_error());
$row_rsTemario2 = mysql_fetch_assoc($rsTemario2);
$totalRows_rsTemario2 = mysql_num_rows($rsTemario2);

$colname_rsTemario3 = "-1";
if (isset($_GET['id_participante'])) {
  $colname_rsTemario3 = $_GET['id_participante'];
}
mysql_select_db($database_cnn_cms, $cnn_cms);
$query_rsTemario3 = sprintf("SELECT t_resultados.id_resultado, t_resultados.id_participante, t_resultados.id_pregunta, t_resultados.respuesta, t_resultados.opcion, t_resultados.entrega, t_resultados.fecha_respuesta, t_preguntas.pregunta, t_preguntas.opcion_1, t_preguntas.opcion_2, t_preguntas.opcion_3, t_preguntas.opcion_4, t_preguntas.id_temario, t_preguntas.puntaje FROM t_resultados INNER JOIN t_preguntas ON t_preguntas.id_pregunta = t_resultados.id_pregunta WHERE t_resultados.id_participante = %s AND t_resultados.entrega=3", GetSQLValueString($colname_rsTemario3, "int"));
$rsTemario3 = mysql_query($query_rsTemario3, $cnn_cms) or die(mysql_error());
$row_rsTemario3 = mysql_fetch_assoc($rsTemario3);
$totalRows_rsTemario3 = mysql_num_rows($rsTemario3);

$colname_rsTemario4 = "-1";
if (isset($_GET['id_participante'])) {
  $colname_rsTemario4 = $_GET['id_participante'];
}
mysql_select_db($database_cnn_cms, $cnn_cms);
$query_rsTemario4 = sprintf("SELECT t_resultados.id_resultado, t_resultados.id_participante, t_resultados.id_pregunta, t_resultados.respuesta, t_resultados.opcion, t_resultados.entrega, t_resultados.fecha_respuesta, t_preguntas.pregunta, t_preguntas.opcion_1, t_preguntas.opcion_2, t_preguntas.opcion_3, t_preguntas.opcion_4, t_preguntas.id_temario, t_preguntas.puntaje FROM t_resultados INNER JOIN t_preguntas ON t_preguntas.id_pregunta = t_resultados.id_pregunta WHERE t_resultados.id_participante = %s AND t_resultados.entrega=4", GetSQLValueString($colname_rsTemario4, "int"));
$rsTemario4 = mysql_query($query_rsTemario4, $cnn_cms) or die(mysql_error());
$row_rsTemario4 = mysql_fetch_assoc($rsTemario4);
$totalRows_rsTemario4 = mysql_num_rows($rsTemario4);
?>
<a href="index.php?opcion=backup&amp;backup=1" class="btn btn-large"><i class="icon-download-alt"></i> Generar una Copia de la Base de Datos</a>
<form action="../demo/index.php" method="get" name="frmBusqueda">
C&eacute;dula: <input name="id_participante" type="text" value="<?php echo $_GET['id_participante'];?>" />
<input name="opcion" type="hidden" value="eliminar_resultados" />
</form>
Nombre usuario: <?php echo utf8_encode($row_rsUsuario['nombres']); ?></br>
Apellidos usuario: <?php echo utf8_encode($row_rsUsuario['apellidos']); ?><br>
Usuario: <?php echo utf8_encode($row_rsUsuario['usuario']); ?><br>
Contraseña: <?php echo htmlentities($row_rsUsuario['clave'], ENT_COMPAT, ''); ?><br>
Distrito: <?php echo utf8_encode($row_rsUsuario['distrito']); ?><br>
  Empresa: <?php echo utf8_encode($row_rsUsuario['empresa']); ?><br>
E-mail: <?php echo utf8_encode($row_rsUsuario['email']); ?><br />


<h3>Temario 1 <a class="btn btn-danger" href="eliminar_resultados_exe.php?opcion=eliminar_resultados&amp;id_participante=<?php echo $_GET['id_participante'];?>&amp;entrega=1"><i class="icon-trash icon-white"></i> Borrar</a></h3> 
<table class="table table-condensed">
<thead>
  <tr>
    <th>ID</th>
    <th>Pregunta</th>
    <th>Respuesta Correcta</th>
    <th>Respuesta Seleccionada</th>
    <th>Fecha</th>
    <th>Puntaje Obtenido</th>
  </tr>
</thead>
<tbody>
  <?php do { ?>
    <tr>
      <td><?php echo utf8_encode($row_rsTemario1['id_resultado']); ?></td>
      <td><?php echo utf8_encode($row_rsTemario1['id_pregunta']); ?>. <?php echo utf8_encode($row_rsTemario1['pregunta']); ?></td>
      <td><?php echo  utf8_encode($row_rsTemario1['opcion_'.$row_rsTemario1['respuesta'].'']);?></td>
      <td><?php echo  utf8_encode($row_rsTemario1['opcion_'.$row_rsTemario1['opcion'].'']);?></td>
      <td><?php echo utf8_encode($row_rsTemario1['fecha_respuesta']); ?></td>
      <td><div align="right"><?php if ($row_rsTemario1['respuesta']==$row_rsTemario1['opcion']) {echo number_format($row_rsTemario1['puntaje']);$acumulado+=$row_rsTemario1['puntaje'];}  ?></div></td>
    </tr>
    <?php } while ($row_rsTemario1 = mysql_fetch_assoc($rsTemario1)); ?>
        <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>Puntaje Temario1:</td>
      <td><div align="right"><?php echo number_format($acumulado); $global+=$acumulado; $acumulado=0; ?></div></td>
    </tr>
    </tbody>
</table>

<h3>Temario 2 <a class="btn btn-danger" href="eliminar_resultados_exe.php?opcion=eliminar_resultados&amp;id_participante=<?php echo $_GET['id_participante'];?>&amp;entrega=2"><i class="icon-trash icon-white"></i> Borrar</a></h3> 
<table class="table table-condensed">
<thead>
  <tr>
    <th>ID</th>
    <th>Pregunta</th>
    <th>Respuesta Correcta</th>
    <th>Respuesta Seleccionada</th>
    <th>Fecha</th>
    <th>Puntaje Obtenido</th>
  </tr>
</thead>
<tbody>
  <?php do { ?>
    <tr>
      <td><?php echo utf8_encode($row_rsTemario2['id_resultado']); ?></td>
      <td><?php echo utf8_encode($row_rsTemario2['id_pregunta']); ?>. <?php echo utf8_encode($row_rsTemario2['pregunta']); ?></td>
      <td><?php echo  utf8_encode($row_rsTemario2['opcion_'.$row_rsTemario2['respuesta'].'']);?></td>
      <td><?php echo  utf8_encode($row_rsTemario2['opcion_'.$row_rsTemario2['opcion'].'']);?></td>
      <td><?php echo utf8_encode($row_rsTemario2['fecha_respuesta']); ?></td>
      <td><div align="right"><?php if ($row_rsTemario2['respuesta']==$row_rsTemario2['opcion']) {echo number_format($row_rsTemario2['puntaje']);$acumulado+=$row_rsTemario2['puntaje'];}  ?></div></td>
    </tr>
    <?php } while ($row_rsTemario2 = mysql_fetch_assoc($rsTemario2)); ?>
        <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>Puntaje Temario 2:</td>
      <td><div align="right"><?php echo number_format($acumulado); $global+=$acumulado; $acumulado=0; ?></div></td>
    </tr>
    </tbody>
</table>

<h3>Temario 3<a class="btn btn-danger" href="eliminar_resultados_exe.php?opcion=eliminar_resultados&amp;id_participante=<?php echo $_GET['id_participante'];?>&amp;entrega=3"><i class="icon-trash icon-white"></i> Borrar</a></h3> 
<table class="table table-condensed">
<thead>
  <tr>
    <th>ID</th>
    <th>Pregunta</th>
    <th>Respuesta Correcta</th>
    <th>Respuesta Seleccionada</th>
    <th>Fecha</th>
    <th>Puntaje Obtenido</th>
  </tr>
</thead>
<tbody>
  <?php do { ?>
    <tr>
      <td><?php echo utf8_encode($row_rsTemario3['id_resultado']); ?></td>
      <td><?php echo utf8_encode($row_rsTemario3['id_pregunta']); ?>. <?php echo utf8_encode($row_rsTemario3['pregunta']); ?></td>
      <td><?php echo  utf8_encode($row_rsTemario3['opcion_'.$row_rsTemario3['respuesta'].'']);?></td>
      <td><?php echo  utf8_encode($row_rsTemario3['opcion_'.$row_rsTemario3['opcion'].'']);?></td>
      <td><?php echo utf8_encode($row_rsTemario3['fecha_respuesta']); ?></td>
      <td><div align="right"><?php if ($row_rsTemario3['respuesta']==$row_rsTemario3['opcion']) {echo number_format($row_rsTemario3['puntaje']);$acumulado+=$row_rsTemario3['puntaje'];}  ?></div></td>
    </tr>
    <?php } while ($row_rsTemario3 = mysql_fetch_assoc($rsTemario3)); ?>
        <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>Puntaje Temario 3:</td>
      <td><div align="right"><?php echo number_format($acumulado); $global+=$acumulado; $acumulado=0; ?></div></td>
    </tr>
    </tbody>
</table>

<h3>Temario 4 <a class="btn btn-danger" href="index.php?opcion=eliminar_resultados&amp;id_participante=<?php echo $_GET['id_participante'];?>&amp;entrega=4"><i class="icon-trash icon-white"></i> Borrar</a></h3> 
<table class="table table-condensed">
<thead>
  <tr>
    <th>ID</th>
    <th>Pregunta</th>
    <th>Respuesta Correcta</th>
    <th>Respuesta Seleccionada</th>
    <th>Fecha</th>
    <th>Puntaje Obtenido</th>
  </tr>
</thead>
<tbody>
  <?php do { ?>
    <tr>
      <td><?php echo utf8_encode($row_rsTemario4['id_resultado']); ?></td>
      <td><?php echo utf8_encode($row_rsTemario4['id_pregunta']); ?>. <?php echo utf8_encode($row_rsTemario4['pregunta']); ?></td>
      <td><?php echo  utf8_encode($row_rsTemario4['opcion_'.$row_rsTemario4['respuesta'].'']);?></td>
      <td><?php echo  utf8_encode($row_rsTemario4['opcion_'.$row_rsTemario4['opcion'].'']);?></td>
      <td><?php echo utf8_encode($row_rsTemario4['fecha_respuesta']); ?></td>
      <td><div align="right"><?php if ($row_rsTemario4['respuesta']==$row_rsTemario4['opcion']) {echo number_format($row_rsTemario4['puntaje']);$acumulado+=$row_rsTemario4['puntaje'];}  ?></div></td>
    </tr>
    <?php } while ($row_rsTemario4 = mysql_fetch_assoc($rsTemario4)); ?>
        <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>Puntaje Temario 4:</td>
      <td><div align="right"><?php echo number_format($acumulado); $global+=$acumulado; $acumulado=0; ?></div></td>
    </tr>
    </tbody>
</table>

<h2 align="center">Puntaje Acumulado : <?php echo number_format($global); ?></h2>
<?php
mysql_free_result($rsUsuario);

mysql_free_result($rsTemario1);

mysql_free_result($rsTemario2);

mysql_free_result($rsTemario3);

mysql_free_result($rsTemario4);
?>
