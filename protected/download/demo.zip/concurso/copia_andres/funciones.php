<?php require_once('Connections/cnn_avantel.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

# SELECCION GRUPO DE PREGUNTAS DE ACUERDO A LA ENTREGA Y DE ACUERDO AL PUNTAJE

function seleccion_grupo($tema) {

include('Connections/cnn_avantel.php');

$srema_rsGrupo = "-1";
if (isset($tema)) {
  $srema_rsGrupo = $tema;
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsGrupo = sprintf("SELECT t_preguntas.id_pregunta, t_preguntas.pregunta, t_preguntas.opcion_1, t_preguntas.opcion_2, t_preguntas.opcion_3, t_preguntas.opcion_4, t_preguntas.id_temario, t_preguntas.puntaje, t_respuestas.respuesta, t_temarios.temario FROM t_preguntas INNER JOIN t_respuestas ON t_respuestas.id_pregunta = t_preguntas.id_pregunta INNER JOIN t_temarios ON t_temarios.id_temario = t_preguntas.id_temario WHERE t_temarios.id_temario = %s ORDER BY RAND() LIMIT 10  ", GetSQLValueString($srema_rsGrupo, "int"));
$rsGrupo = mysql_query($query_rsGrupo, $cnn_avantel) or die(mysql_error());
$row_rsGrupo = mysql_fetch_assoc($rsGrupo);
$totalRows_rsGrupo = mysql_num_rows($rsGrupo);

do { 
			$grupo[]=array(
						   "id"=>$row_rsGrupo['id_pregunta'],
						   "pregunta"=>$row_rsGrupo['pregunta'],
						   "opcion_1"=>$row_rsGrupo['opcion_1'],
						   "opcion_2"=>$row_rsGrupo['opcion_2'],
						   "opcion_3"=>$row_rsGrupo['opcion_3'],
						   "opcion_4"=>$row_rsGrupo['opcion_4'],
						   "id_tema"=>$row_rsGrupo['id_temario'],
						   "tema"=>$row_rsGrupo['temario'],
						   "respuesta"=>$row_rsGrupo['respuesta'],
						   "valor"=>$row_rsGrupo['puntaje'],
						   );
} while ($row_rsGrupo = mysql_fetch_assoc($rsGrupo));

return $grupo;

mysql_free_result($rsGrupo);
}



# VERIFICACI�N DE LAS EXISTENCIA DE PREGRUNTAS YA INSERTADAS PARA EL USUARIO SEG�N LA ENTREGA



function entrega_participante($participante,$entrega) {

include('Connections/cnn_avantel.php');

$sparticipante_rsEntrega = "-1";
if (isset($participante)) {
  $sparticipante_rsEntrega = $participante;
}
$sentrega_rsEntrega = "-1";
if (isset($entrega)) {
  $sentrega_rsEntrega = $entrega;
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsEntrega = sprintf("SELECT DISTINCT entrega FROM  t_resultados WHERE id_participante = %s AND entrega = %s ", GetSQLValueString($sparticipante_rsEntrega, "int"), GetSQLValueString($sentrega_rsEntrega, "int"));
$rsEntrega = mysql_query($query_rsEntrega, $cnn_avantel) or die(mysql_error());
$row_rsEntrega = mysql_fetch_assoc($rsEntrega);
$totalRows_rsEntrega = mysql_num_rows($rsEntrega);

if (isset($row_rsEntrega['entrega'])) {return 1;} else {return 0;}

mysql_free_result($rsEntrega);
}


# RECUPERACI�N DE LAS PREGUNTAS DE ACUERDO A LA ENTREGA



function recuperar_preguntas($participante, $entrega) {

include('Connections/cnn_avantel.php');

$sparticipante_rsPreguntas = "-1";
if (isset($participante)) {
  $sparticipante_rsPreguntas = $participante;
}
$sentrega_rsPreguntas = "-1";
if (isset($entrega)) {
  $sentrega_rsPreguntas = $entrega;
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsPreguntas = sprintf("SELECT t_resultados.id_pregunta, t_temarios.temario,  t_preguntas.pregunta, t_preguntas.opcion_1, t_preguntas.opcion_2, t_preguntas.opcion_3, t_preguntas.opcion_4, t_preguntas.id_temario, t_preguntas.puntaje, t_resultados.id_participante, t_resultados.respuesta, t_resultados.opcion, t_resultados.puntaje, t_resultados.entrega, t_resultados.fecha_respuesta, t_resultados.id_resultado FROM t_resultados INNER JOIN t_preguntas ON t_preguntas.id_pregunta = t_resultados.id_pregunta INNER JOIN t_temarios ON t_temarios.id_temario = t_preguntas.id_temario WHERE t_resultados.id_participante = %s AND t_resultados.entrega = %s ", GetSQLValueString($sparticipante_rsPreguntas, "int"),GetSQLValueString($sentrega_rsPreguntas, "int"));
$rsPreguntas = mysql_query($query_rsPreguntas, $cnn_avantel) or die(mysql_error());
$row_rsPreguntas = mysql_fetch_assoc($rsPreguntas);
$totalRows_rsPreguntas = mysql_num_rows($rsPreguntas);

do { 
			$preguntas[]=array(
						   "id"=>$row_rsPreguntas['id_pregunta'],
						   "pregunta"=>$row_rsPreguntas['pregunta'],
						   "opcion_1"=>$row_rsPreguntas['opcion_1'],
						   "opcion_2"=>$row_rsPreguntas['opcion_2'],
						   "opcion_3"=>$row_rsPreguntas['opcion_3'],
						   "opcion_4"=>$row_rsPreguntas['opcion_4'],
						   "id_tema"=>$row_rsPreguntas['id_temario'],
						   "tema"=>$row_rsPreguntas['temario'],
						   "respuesta"=>$row_rsPreguntas['respuesta'],
						   "valor"=>$row_rsPreguntas['puntaje'],
						   "seleccion"=>$row_rsPreguntas['opcion'],
						   "id_resultado"=>$row_rsPreguntas['id_resultado'],
						   );
} while ($row_rsPreguntas = mysql_fetch_assoc($rsPreguntas));

return $preguntas;

mysql_free_result($rsPreguntas);
}


# IDENTIFICAR LA ENTREGA POR LAS FECHAS

function nombre_entrega() {

include('Connections/cnn_avantel.php');

mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsNombreEntrega = "SELECT * FROM t_temarios WHERE fecha_lanzamiento >  CURDATE() AND fecha_cierre < CURDATE()";
$rsNombreEntrega = mysql_query($query_rsNombreEntrega, $cnn_avantel) or die(mysql_error());
$row_rsNombreEntrega = mysql_fetch_assoc($rsNombreEntrega);
$totalRows_rsNombreEntrega = mysql_num_rows($rsNombreEntrega);

if (isset($row_rsNombreEntrega['id_temario'])) {return $row_rsNombreEntrega['temario'];} else {return 0;}

mysql_free_result($rsTemario);
}


# DETERMINAR EL TIEMPO RESTANTE PARA LA PRUEBA

function tiempo_restante($participante,$entrega) {
include('Connections/cnn_avantel.php');

$sparticipante_rsTiempoRestante = "-1";
if (isset($participante)) {
  $sparticipante_rsTiempoRestante = $participante;
}
$sentrega_rsTiempoRestante = "-1";
if (isset($entrega)) {
  $sentrega_rsTiempoRestante = $entrega;
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
#$query_rsTiempoRestante = sprintf("SELECT DATE_ADD( MIN( fecha_respuesta ) , INTERVAL 2 HOUR ) AS fecha_cierre_prueba, TIMEDIFF( DATE_ADD( MIN( fecha_respuesta ) , INTERVAL 2 HOUR ) , NOW( ) ) AS tiempo_cronometro, TIMESTAMPDIFF(SECOND , NOW( ) , DATE_ADD( MIN( fecha_respuesta ) , INTERVAL 2 HOUR ) ) AS segundos_restantes FROM t_resultados WHERE id_participante = %s AND entrega = %s ", GetSQLValueString($sparticipante_rsTiempoRestante, "int"), GetSQLValueString($sentrega_rsTiempoRestante, "int"));
$query_rsTiempoRestante = sprintf("SELECT DATE_ADD( MIN( fecha_respuesta ) , INTERVAL 2 HOUR ) AS fecha_cierre_prueba, TIMEDIFF( DATE_ADD( MIN( fecha_respuesta ) , INTERVAL 2 HOUR ) , DATE_ADD(NOW( ), INTERVAL 1 HOUR) ) AS tiempo_cronometro, TIMESTAMPDIFF(SECOND , DATE_ADD(NOW( ), INTERVAL 1 HOUR) , DATE_ADD( MIN( fecha_respuesta ) , INTERVAL 2 HOUR ) ) AS segundos_restantes FROM t_resultados WHERE id_participante = %s AND entrega = %s ", GetSQLValueString($sparticipante_rsTiempoRestante, "int"), GetSQLValueString($sentrega_rsTiempoRestante, "int"));
$rsTiempoRestante = mysql_query($query_rsTiempoRestante, $cnn_avantel) or die(mysql_error());
$row_rsTiempoRestante = mysql_fetch_assoc($rsTiempoRestante);
$totalRows_rsTiempoRestante = mysql_num_rows($rsTiempoRestante);
if (isset($row_rsTiempoRestante['fecha_cierre_prueba'])) {
  $cronometro=array($row_rsTiempoRestante['fecha_cierre_prueba'],$row_rsTiempoRestante['tiempo_cronometro'],$row_rsTiempoRestante['segundos_restantes']);
} else { 
 $cronometro = array(999,'02:00:00',7200);
}

return $cronometro;

mysql_free_result($rsTiempoRestante);
}




# VERIFICAR SI YA SE RESPONDI� LA ENTREGA

function estado_entrega($participante,$entrega) {

include('Connections/cnn_avantel.php');

$sparticipante_rsEntrega = "-1";
if (isset($participante)) {
  $sparticipante_rsEntrega = $participante;
}
$sentrega_rsEntrega = "-1";
if (isset($entrega)) {
  $sentrega_rsEntrega = $entrega;
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsEntrega = sprintf("SELECT * FROM  t_resultados WHERE opcion IS NULL AND id_participante = %s AND entrega = %s", GetSQLValueString($sparticipante_rsEntrega, "int"), GetSQLValueString($sentrega_rsEntrega, "int"));
$rsEntrega = mysql_query($query_rsEntrega, $cnn_avantel) or die(mysql_error());
$row_rsEntrega = mysql_fetch_assoc($rsEntrega);
$totalRows_rsEntrega = mysql_num_rows($rsEntrega);

if (isset($row_rsEntrega['entrega'])) {return 1;} else {return 0;}

mysql_free_result($rsEntrega);
}

# PUNTAJE DE  LA ENTREGA

function puntaje_entrega($participante,$entrega) {

include('Connections/cnn_avantel.php');

$sparticipante_rsEntrega = "-1";
if (isset($participante)) {
  $sparticipante_rsEntrega = $participante;
}
$sentrega_rsEntrega = "-1";
if (isset($entrega)) {
  $sentrega_rsEntrega = $entrega;
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsEntrega = sprintf("SELECT SUM(IF(t_resultados.respuesta=t_resultados.opcion,t_resultados.puntaje,0)) AS puntaje_entrega FROM t_resultados
WHERE t_resultados.id_participante = %s AND t_resultados.entrega = %s ", GetSQLValueString($sparticipante_rsEntrega, "int"), GetSQLValueString($sentrega_rsEntrega, "int"));
$rsEntrega = mysql_query($query_rsEntrega, $cnn_avantel) or die(mysql_error());
$row_rsEntrega = mysql_fetch_assoc($rsEntrega);
$totalRows_rsEntrega = mysql_num_rows($rsEntrega);

return $row_rsEntrega['puntaje_entrega'];

mysql_free_result($rsEntrega);
}

# PUNTAJE ACUMULADO

function puntaje_acumulado($participante) {

include('Connections/cnn_avantel.php');

$sparticipante_rsGlobal = "-1";
if (isset($participante)) {
  $sparticipante_rsGlobal = $participante;
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsGlobal = sprintf("SELECT SUM(IF(t_resultados.respuesta=t_resultados.opcion,t_resultados.puntaje,0)) AS puntaje_acumulado FROM t_resultados
WHERE t_resultados.id_participante = %s", GetSQLValueString($sparticipante_rsGlobal, "int"));
$rsGlobal = mysql_query($query_rsGlobal, $cnn_avantel) or die(mysql_error());
$row_rsGlobal = mysql_fetch_assoc($rsGlobal);
$totalRows_rsGlobal = mysql_num_rows($rsGlobal);

return $row_rsGlobal['puntaje_acumulado'];

mysql_free_result($rsGlobal);
}


# FECHA PRESENTACION ENTREGA

function fecha_presentacion_entrega($participante,$entrega) {

include('Connections/cnn_avantel.php');

$sparticipante_rsFechaPresentacion = "-1";
if (isset($participante)) {
  $sparticipante_rsFechaPresentacion = $participante;
}
$sentrega_rsFechaPresentacion = "-1";
if (isset($entrega)) {
  $sentrega_rsFechaPresentacion = $entrega;
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsFechaPresentacion = sprintf("SELECT MAX(fecha_respuesta) AS fecha_presentacion FROM t_resultados WHERE t_resultados.id_participante = %s AND entrega = %s ", GetSQLValueString($sparticipante_rsFechaPresentacion, "int"), GetSQLValueString($sentrega_rsFechaPresentacion, "int"));
$rsFechaPresentacion = mysql_query($query_rsFechaPresentacion, $cnn_avantel) or die(mysql_error());
$row_rsFechaPresentacion = mysql_fetch_assoc($rsFechaPresentacion);
$totalRows_rsFechaPresentacion = mysql_num_rows($rsFechaPresentacion);

return $row_rsFechaPresentacion['fecha_presentacion'];

mysql_free_result($rsFechaPresentacion);

}


/**
 * Returns a number of random elements from an array.
 *
 * It returns the number (specified in $limit) of elements from
 * $array. The elements are returned in a random order, exactly
 * as it was passed to the function. (So, it's safe for multi-
 * dimensional arrays, aswell as array's where you need to keep
 * the keys)
 *
 * @author Brendan Caffrey  <bjcffnet at gmail dot com>
 * @param  array  $array  The array to return the elements from
 * @param  int    $limit  The number of elements to return from
 *                            the array
 * @return array  The randomized array
 */
function array_rand_keys($array, $limit = 1) {
    $count = @count($array)-1;

    // Sanity checks
    if ($limit == 0 || !is_array($array) || $limit > $count) return array();
    if ($count == 1) return $array;

    // Loop through and get the random numbers
    for ($x = 0; $x < $limit; $x++) {
        $rand = rand(0, $count);

        // Can't have double randoms, right?
        while (isset($rands[$rand])) $rand = rand(0, $count);

        $rands[$rand] = $rand;
    }

    $return = array();
    $curr = current($rands);

    // I think it's better to return the elements in a random
    // order, which is why I'm not just using a foreach loop to
    // loop through the random numbers
    while (count($return) != $limit) {
        $cur = 0;

        foreach ($array as $key => $val) {
            if ($cur == $curr) {
                $return[$key] = $val;

                // Next...
                $curr = next($rands);
                continue 2;
            } else {
                $cur++;
            }
        }
    }

    return $return;
}


?>
