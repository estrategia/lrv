<?php 
require_once('Connections/cnn_avantel.php');
if (!isset($base_url)) {
  $base_url="/demo/";
}
if (!isset($_SESSION)) {
  session_start();
}
if (!isset($_SESSION['MM_Username'])) {
  header('Location: login.php');
} 
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "CambiarCon")) {
  $updateSQL = sprintf("UPDATE t_participantes SET clave=%s WHERE id_participante=%s",
                       GetSQLValueString($_POST['rncontrasena'], "text"),
                       GetSQLValueString($_POST['id_participante'], "int"));

  mysql_select_db($database_cnn_avantel, $cnn_avantel);
  $Result1 = mysql_query($updateSQL, $cnn_avantel) or die(mysql_error());
  header("Location: datos_participante.php");
}

$colname_rsUsuario = "-1";
if (isset($_SESSION['MM_ID'])) {
  $colname_rsUsuario = $_SESSION['MM_ID'];
}
mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsUsuario = sprintf("SELECT * FROM t_participantes WHERE id_participante = %s", GetSQLValueString($colname_rsUsuario, "int"));
$rsUsuario = mysql_query($query_rsUsuario, $cnn_avantel) or die(mysql_error());
$row_rsUsuario = mysql_fetch_assoc($rsUsuario);
$totalRows_rsUsuario = mysql_num_rows($rsUsuario);
?>
<!-- <img src="<?php echo $base_url; ?>img/avantel_logo.png" class="img-responsive top_login hidden-xs"> -->
<!-- <img src="<?php echo $base_url; ?>img/concurso/top_contenedores.png" class="top_login visible-xs img-responsive"> -->
<div class="middle_login_3">
<!-- <p style="text-align:right;">
  <img src="<?php echo $base_url; ?>img/lg_coopcarvajal.png" alt="Coopcarvajal - 70años contigo!"  class="img-responsive">
</p> -->
<!-- <p class="datos"><strong>Tus datos en nuestro sistema son:</strong></p> -->
<img style="width: 320px;" src="img/cambiar_contrasena.png">
<br>
<br>
<p style="position: relative; left: 25px;">
  Nombre usuario: <?php echo utf8_encode($row_rsUsuario['nombres']); ?></br>
  Apellidos usuario: <?php echo utf8_encode($row_rsUsuario['apellidos']); ?><br>
  Usuario: <?php echo utf8_encode($row_rsUsuario['usuario']); ?><br>
  Contraseña: <?php echo htmlentities($row_rsUsuario['clave'], ENT_COMPAT, ''); ?><br>
  Ciudad: <?php echo utf8_encode($row_rsUsuario['distrito']); ?><br>
  Área: <?php echo utf8_encode($row_rsUsuario['empresa']); ?><br>
  E-mail: <?php echo utf8_encode($row_rsUsuario['email']); ?>
</p>
<br>
<form method="post" name="form1" action="../demo/CambiarCon.php" id="CambiarCon" role="form">
  <div class="form-group">
    <span><img src="img/ico-sesion-3.png"> </span><label for="ncontrasena">&nbsp; Nueva Contraseña:</label>
    <input type="password" class="form-control" placeholder="Nueva contraseña" name="ncontrasena">
  </div>
  <div class="form-group">
    <span><img src="img/ico-sesion-3.png"> </span><label for="rncontrasena">&nbsp; Confirmar contraseña</label>
    <input type="password" class="form-control" placeholder="Repite nueva contraseña" name="rncontrasena">
  </div>
  <br>
  <br>
  <div class="form-group" align="center">
    <button style="background-color: transparent; border: none;" type="button" onclick="validar_CambiarCon()"><img src="img/cambiar.png"></button>
  </div>
  <input type="hidden" name="MM_update" value="CambiarCon" >
  <input type="hidden" name="id_participante" value="<?php echo $row_rsUsuario['id_participante']; ?>">
</form>
</div>
    <script type="text/javascript">
      function script_add(){
        $('#ModalConcurso').removeClass('login_concurso');
        $('#ModalConcurso').addClass('datos_participante');
      }
    </script>
<?php 
mysql_free_result($rsUsuario);
?>