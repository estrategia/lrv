<?php
if (!isset($base_url)) {
  $base_url="/";
}
 include("../demo/temarios.php");?>
 <img src="<?php echo $base_url; ?>img/concurso/top_contenedor_blanco.png" class="top_blanco_general img-responsive visible-xs">
<img class="img-responsive lg-coopcarvajal" src="<?php echo $base_url; ?>img/lg_coopcarvajal.png" alt="Coopcarvajal - 70 años">
 <div class="conte_introduccion">
<h2 class="title_intro morado_font">
<img  class="img-responsive" src="<?php echo $base_url; ?>img/concurso/deportes/saludo_bienvenida.png" alt="... Nos encanta que estén aquí en el destino del Tour">
</h2>
<h3 class="villa_coop turquesa_font"><img class="img-responsive" src="<?php echo $base_url; ?>img/concurso/deportes/villa_deportes.png" alt="Villa deportes 10mil millas a ganar por una lavadora"></h3>

<p><img src="<?php echo $base_url; ?>img/concurso/deportes/villa_deportes3.png" class="img-responsive lat-right"></p>
<img src="<?php echo $base_url; ?>img/concurso/deportes/villa_deportes2.png" class="img-responsive lat-left">
<div class="group_button">
<a href="../demo/alerta.php" datanamehref="hrefajax" class="btn_azul">Juego de Prueba</a>
<a href="alerta.php" datanamehref="hrefajax" class="btn_rojo">Jugar</a>
</div>
</div>
 <img src="<?php echo $base_url; ?>img/concurso/bottom_contenedor_blanco.png" class="bottom_blanco_general img-responsive  visible-xs">
<script type="text/javascript">
  function script_add(){
  	$('#ModalConcurso').removeClass('datos_participante');
$('#ModalConcurso').removeClass('t_puntaje');
    $('#ModalConcurso').addClass('introduccion');
  }
</script>
