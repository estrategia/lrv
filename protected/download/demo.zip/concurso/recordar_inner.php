<div id="resultcontrol_contra" dataParentForm="resultcontrol_contra">
            <div class="middle_login">
              <form id="recordar_contra" role="form" method="post" action="../demo/recordar.php" style="clear: both; padding-top: 35px;">
                  <div class="form-group">
                    <span ><img src="img/ico-sesion.png"> </span><label style="margin-bottom: 10px;" for="user">Usuario</label>
                    <input type="text" placeholder="Número de Cédula del Afiliado" id="user" class="form-control" name="user">
        <?php if($totalRows_rs_participantes==0 && isset($_POST['recordar'])){  ?> <p class="error_login" >Credenciales Incorrectas.</p><?php }?>
                  </div>
                  <div class="space"></div>

                  <div class="row">
                    <div class="col-sm-6">
                      <img src="<?php echo $base_url; ?>img/avantel_logo.png" alt="" width="137" class="img-responsive">
                    </div>
                    <div class="col-sm-6" align="right">
                      <!-- <button style="background-color: transparent; border: none;" type="button" onclick="validar_recordar();"><img src="<?php echo $base_url ?>img/validar.png"></button> -->
                      <div class="row">
                    <div align="center" class="col-sm-12 ">
                      <input type="hidden" name="recordar" value="recordar">
                      <button style="background-color: transparent; border: none;" type="button" onclick="validar_recordar();"><img src="<?php echo $base_url ?>img/validar.png"></button>
                    </div>
                  </div>
                    </div>
                  </div>
                   
                   
                  
              </form>
            </div>
            
            </div>
