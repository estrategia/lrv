<?php require_once('Connections/cnn_avantel.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
 
 $updateSQL = sprintf("UPDATE t_resultados SET opcion=%s, fecha_respuesta=%s WHERE id_resultado=%s",
                       GetSQLValueString($_POST['opcion'], "int"),
                       GetSQLValueString($_POST['fecha_respuesta'], "date"),
                       GetSQLValueString($_POST['id_resultado'], "int"));

  mysql_select_db($database_cnn_avantel, $cnn_avantel);
  $Result1 = mysql_query($updateSQL, $cnn_avantel) or die(mysql_error());
  
  $updateGoTo = "cuestionario.php?siguiente=".$_POST['siguiente'];
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
 
  ?>