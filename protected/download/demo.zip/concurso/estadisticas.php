<?php require_once('Connections/cnn_avantel.php'); ?>

<?php

if (!function_exists("GetSQLValueString")) {

function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 

{

  if (PHP_VERSION < 6) {

    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  }



  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);



  switch ($theType) {

    case "text":

      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";

      break;    

    case "long":

    case "int":

      $theValue = ($theValue != "") ? intval($theValue) : "NULL";

      break;

    case "double":

      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";

      break;

    case "date":

      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";

      break;

    case "defined":

      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;

      break;

  }

  return $theValue;

}

}



mysql_select_db($database_cnn_avantel, $cnn_avantel);

$query_rsParticipantes = "SELECT DISTINCT t_resultados.id_participante, t_participantes.nombres, t_participantes.apellidos, t_participantes.distrito, t_participantes.empresa, t_participantes.email, t_participantes.email_2, t_participantes.email_3, t_participantes.email_4 FROM t_resultados INNER JOIN t_participantes ON t_participantes.id_participante = t_resultados.id_participante ";

$rsParticipantes = mysql_query($query_rsParticipantes, $cnn_avantel) or die(mysql_error());

$row_rsParticipantes = mysql_fetch_assoc($rsParticipantes);

$totalRows_rsParticipantes = mysql_num_rows($rsParticipantes);





$fecha_actual=date('Y-m-d H_i_s');

include("../demo/funciones.php");

header("Content-type: application/vnd.ms-excel");

//indicamos al navegador que se estÃ¡ devolviendo un archivo

header("Content-Disposition: attachment; filename=tour_del_saber_".$fecha_actual.".xls");

//con esto evitamos que el navegador lo grabe en su cachÃ©

header("Pragma: no-cache");

header("Expires: 0");

?>



<table border="1">

  <tr>

    <td>Identificaci&oacute;n</td>

    <td>Nombres</td>

    <td>Apellidos</td>

    <td>Distrito</td>

    <td>Empresa</td>

    <td>eMail 1</td>

    <td>eMail 2</td>

    <td>eMail 3</td>

    <td>eMail 4</td>

    <td>Entrega 1</td>

    <td>Entrega 2</td>

    <td>Entrega 3</td>

    <td>Entrega</td>

    <td>Acumulado</td>

  </tr>

  <?php do { ?>

    <tr>

      <td><?php echo $row_rsParticipantes['id_participante']; ?></td>

      <td><?php echo $row_rsParticipantes['nombres']; ?></td>

      <td><?php echo $row_rsParticipantes['apellidos']; ?></td>

      <td><?php echo $row_rsParticipantes['distrito']; ?></td>

      <td><?php echo $row_rsParticipantes['empresa']; ?></td>

      <td><?php echo $row_rsParticipantes['email']; ?></td>

      <td><?php echo $row_rsParticipantes['email_2']; ?></td>

      <td><?php echo $row_rsParticipantes['email_3']; ?></td>

      <td><?php echo $row_rsParticipantes['email_4']; ?></td>

      <td><?php echo puntaje_entrega($row_rsParticipantes['id_participante'],1); ?></td>

      <td><?php echo puntaje_entrega($row_rsParticipantes['id_participante'],2); ?></td>

      <td><?php echo puntaje_entrega($row_rsParticipantes['id_participante'],3); ?></td>

      <td><?php echo puntaje_entrega($row_rsParticipantes['id_participante'],4); ?></td>

      <td><?php echo puntaje_acumulado($row_rsParticipantes['id_participante']) ?></td>

    </tr>

    <?php } while ($row_rsParticipantes = mysql_fetch_assoc($rsParticipantes)); ?>

</table>

<?php mysql_free_result($rsParticipantes);?>