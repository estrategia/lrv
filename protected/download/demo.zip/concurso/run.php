
        <script type="text/javascript" src="concurso/includes/nikku/samples/js/jquery.1.6.2.min.js"></script>
        <script type="text/javascript" src="concurso/includes/nikku/samples/js/jquery.controls.js"></script>
        <script type="text/javascript" src="concurso/includes/nikku/samples/js/jquery.form.js"></script>
        <script type="text/javascript" src="concurso/includes/nikku/lib/jquery.dialog2.js"></script>
        <script type="text/javascript" src="concurso/includes/nikku/lib/jquery.dialog2.helpers.js"></script>
        <script type="text/javascript" src="concurso/includes/nikku/samples/js/prettify.js"></script>
        
        <style type="text/css">
            @import url('concurso/includes/nikku/samples/css/prettify.css');
            @import url('concurso/includes/nikku/css/jquery-dialog2/jquery.dialog2.css');
            @import url('concurso/includes/nikku/samples/css/docs.css');
        </style>
        
        <script type="text/javascript">
            $(document).ready(function() {
                prettyPrint();
                
                $(document).controls();
                $(".show-source-link").click(function(event) {
                    event.preventDefault();
                    
                    var link = $(this);
                    var source = link.parents(".activity").nextAll(".source").eq(0);
                    
                    source.toggleClass("open");
                    if (source.is(".open")) {
                        link.text("(Hide source)");
                    } else {
                        link.text("(View source)");
                    }
                });
            });
        </script>
    
    <a class="open-dialog btn btn-primary btn-large" rel="sample2-dialog" href="concurso/login.php">Ingresar</a>
    
   