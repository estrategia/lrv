<?php require_once('Connections/cnn_avantel.php');
if (!isset($base_url)) {
  $base_url="/concurso/";
}
session_start(); 
include("../concurso/temarios.php");
?>
<div class="visible-xs temario_top_<?php echo $entrega; ?>"></div>
<div class="middle_preguntas">
	<img style="margin-left: 20px; margin-top: 20px;" src="img/avantel_logo.png">
<?php


include("../concurso/cronometro.php");


if ($segundos_restantes<=0) {
	$timeout=true;
	include("../concurso/puntaje.php");	
	} else {

/*

 s� no se han seleccionado preguntas se insertan las pregunras
 s� ya se insertaron preguntas para el usuario y la entrega se verifica s� ya respondi� todas las preguntas de la entrega en curso
 	cuando se respondan todas entonces se le muestra mensaje de ya respond�� o la siguiente entrega s� ya es tiempo

*/

# insertar preguntas


if (entrega_participante($_SESSION['MM_ID'],$entrega)==0) { 

foreach ($seleccion as $valor) {

  $insertSQL = sprintf("INSERT INTO t_resultados (id_participante, id_pregunta, respuesta, opcion, puntaje, entrega, fecha_respuesta) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_SESSION['MM_ID'], "int"),
                       GetSQLValueString($valor['id'], "int"),
                       GetSQLValueString($valor['respuesta'], "int"),
                       GetSQLValueString(NULL, "int"),
					   GetSQLValueString($valor['valor'], "int"),
					   GetSQLValueString($entrega, "int"),
                       GetSQLValueString(date('Y-m-d H:i:s'), "date"));

  mysql_select_db($database_cnn_avantel, $cnn_avantel);
  $Result1 = mysql_query($insertSQL, $cnn_avantel) or die(mysql_error());
}
}
?>
<?php 
if (estado_entrega($_SESSION['MM_ID'],$entrega)!=1) {
	include("../concurso/puntaje.php");	
	} else {

	$recuperadas=recuperar_preguntas($_SESSION['MM_ID'],$entrega);
?>
<?php 
if (isset($_GET['siguiente'])) {
$siguiente=$_GET['siguiente'];
}else if(isset($_POST['siguiente'])){
$siguiente=$_POST['siguiente'];
}
	switch($siguiente){ 
		case 1: if (isset($_GET['espera'])==1) {$pregunta_numero=0; $siguiente=1; include("../concurso/correcta.php");} else {$pregunta_numero=0; $siguiente=1; include("../concurso/preguntas.php");}; break;
		case 2: if (isset($_GET['espera'])==1) {$pregunta_numero=0; $siguiente=1; include("../concurso/correcta.php");} else {$pregunta_numero=1; $siguiente=2; include("../concurso/preguntas.php");}; break;
		case 3: if (isset($_GET['espera'])==1) {$pregunta_numero=1; $siguiente=2; include("../concurso/correcta.php");} else {$pregunta_numero=2; $siguiente=3; include("../concurso/preguntas.php");}; break;
		case 4: if (isset($_GET['espera'])==1) {$pregunta_numero=2; $siguiente=3; include("../concurso/correcta.php");} else {$pregunta_numero=3; $siguiente=4; include("../concurso/preguntas.php");}; break;
		case 5: if (isset($_GET['espera'])==1) {$pregunta_numero=3; $siguiente=4; include("../concurso/correcta.php");} else {$pregunta_numero=4; $siguiente=5; include("../concurso/preguntas.php");}; break;
		case 6: if (isset($_GET['espera'])==1) {$pregunta_numero=4; $siguiente=5; include("../concurso/correcta.php");} else {$pregunta_numero=5; $siguiente=6; include("../concurso/preguntas.php");}; break;
		case 7: if (isset($_GET['espera'])==1) {$pregunta_numero=5; $siguiente=6; include("../concurso/correcta.php");} else {$pregunta_numero=6; $siguiente=7; include("../concurso/preguntas.php");}; break;
		case 8: if (isset($_GET['espera'])==1) {$pregunta_numero=6; $siguiente=7; include("../concurso/correcta.php");} else {$pregunta_numero=7; $siguiente=8; include("../concurso/preguntas.php");}; break;
		case 9: if (isset($_GET['espera'])==1) {$pregunta_numero=7; $siguiente=8; include("../concurso/correcta.php");} else {$pregunta_numero=8; $siguiente=9; include("../concurso/preguntas.php");}; break;
		case 10: if (isset($_GET['espera'])==1) {$pregunta_numero=8; $siguiente=9; include("../concurso/correcta.php");} else {$pregunta_numero=9; $siguiente=10; include("../concurso/preguntas.php");}; break;
		case 11: if (isset($_GET['espera'])==1) {$pregunta_numero=9; $siguiente=10; include("../concurso/correcta.php");} else {$pregunta_numero=10; $siguiente=11; include("../concurso/preguntas.php");}; break;
		case 12: if (isset($_GET['espera'])==1) {$pregunta_numero=10; $siguiente=11; include("../concurso/correcta.php");} else {$pregunta_numero=11; $siguiente=12; include("../concurso/preguntas.php");}; break;
		case 13: if (isset($_GET['espera'])==1) {$pregunta_numero=11; $siguiente=12; include("../concurso/correcta.php");} else {$pregunta_numero=12; $siguiente=13; include("../concurso/preguntas.php");}; break;
		case 14: if (isset($_GET['espera'])==1) {$pregunta_numero=12; $siguiente=13; include("../concurso/correcta.php");} else {$pregunta_numero=13; $siguiente=14; include("../concurso/preguntas.php");}; break;
		case 15: if (isset($_GET['espera'])==1) {$pregunta_numero=13; $siguiente=14; include("../concurso/correcta.php");} else {$pregunta_numero=14; $siguiente=15; include("../concurso/preguntas.php");}; break;
		case 16: if (isset($_GET['espera'])==1) {$pregunta_numero=14; $siguiente=15; include("../concurso/correcta.php");} else {$pregunta_numero=15; $siguiente=16; include("../concurso/preguntas.php");}; break;
		case 17: if (isset($_GET['espera'])==1) {$pregunta_numero=15; $siguiente=16; include("../concurso/correcta.php");} else {$pregunta_numero=16; $siguiente=17; include("../concurso/preguntas.php");}; break;
		case 18: if (isset($_GET['espera'])==1) {$pregunta_numero=16; $siguiente=17; include("../concurso/correcta.php");} else {$pregunta_numero=17; $siguiente=18; include("../concurso/preguntas.php");}; break;
		case 19: if (isset($_GET['espera'])==1) {$pregunta_numero=17; $siguiente=18; include("../concurso/correcta.php");} else {$pregunta_numero=18; $siguiente=19; include("../concurso/preguntas.php");}; break;
		case 20: if (isset($_GET['espera'])==1) {$pregunta_numero=18; $siguiente=19; include("../concurso/correcta.php");} else {$pregunta_numero=19; $siguiente=20; include("../concurso/preguntas.php");}; break;
		case 21: if (isset($_GET['espera'])==1) {$pregunta_numero=19; $siguiente=20; include("../concurso/correcta.php");} else {$pregunta_numero=19; $siguiente=20; include("../concurso/preguntas.php");}; break;
	}

?>
<?php } ?>
<?php } ?>
</div>
<div class="visible-xs temario_bottom_<?php echo $entrega; ?>"></div>
<script type="text/javascript">
  function script_add(){
  	$('#ModalConcurso').removeClass('introduccion');
  }
</script>
