2.0.<?php 
if (!isset($base_url)) {
  $base_url="/demo/";
}
 ?>
<img src="<?php echo $base_url; ?>img/concurso/contenedor_purpura_top.png" class="img-responsive visible-xs">
<img class="img-responsive lg-coopcarvajal" src="<?php echo $base_url; ?>img/lg_coopcarvajal.png" alt="Coopcarvajal - 70 años">
<div class="conte_alerta">
 <h2 class="naranja_font">ALERTA!!</h2>
<p>
	Su misi&oacute;n si <i class="turquesa_font">deciden aceptarla</i>, es responder CORRECTAMENTE las siguientes 20 preguntas
</p>


<p>Recuerden que este juego se autocerrar&aacute; en<br> 
	<strong class="turquesa_font">2 horas exactas</strong></p>

<p>El tiempo comenzará a correr <br>
 Vamos a <strong class="turquesa_font">GANAR</strong> y LOS PREMIOS CONQUISTAR</p>


<form action="../demo/cuestionario.php" method="post" name="frmInicio">
<input name="siguiente" type="hidden" value="1">
<button class="btn_rojo" style="margin-top: 16px;">Jugar</button>
</form>
</div>
<img src="<?php echo $base_url; ?>img/concurso/contenedor_purpura_bottom.png" class="img-responsive bottom_alerta  visible-xs">
<script type="text/javascript">
  function script_add(){
  	$('#ModalConcurso').removeClass('introduccion');
    $('#ModalConcurso').addClass('alerta');
  }
</script>
