<?php require_once('Connections/cnn_avantel.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
 if (isset($_POST['grabar'])==1) {
 $updateSQL = sprintf("UPDATE t_resultados SET opcion=%s, fecha_respuesta=%s WHERE id_resultado=%s",
                       GetSQLValueString($_POST['opcion'], "int"),
                       GetSQLValueString($_POST['fecha_respuesta'], "date"),
                       GetSQLValueString($_POST['id_resultado'], "int"));

  mysql_select_db($database_cnn_avantel, $cnn_avantel);
  $Result1 = mysql_query($updateSQL, $cnn_avantel) or die(mysql_error());
  if ($_POST['opcion']==$_POST['correcta']) { $correcta="ok";} else {  $correcta= "";}
  $updateGoTo = "cuestionario.php?siguiente=".$_POST['siguiente']."&espera=1&correcta=".$correcta;
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));  
 }

$base_url="/";
  ?>
<div class="temario_<?php echo $entrega; ?>">
ORIGINAL
<form class="pregruntas" id="form1_<?php echo $pregunta_numero; ?>" name="form1_<?php echo $pregunta_numero; ?>" method="post" action="preguntas.php" class="ajax">

 
<p style="text-align:justify"><?php echo $pregunta_numero+1; ?>. <?php  echo utf8_encode($recuperadas[$pregunta_numero]['pregunta']); ?></p>
    
        <label class="radio">
          <input <?php if (!(strcmp($recuperadas[$pregunta_numero]['seleccion'],"1"))) {echo "checked=\"checked\"";} ?> type="radio" name="opcion" value="1" id="opcion_1" />
          <?php  echo utf8_encode($recuperadas[$pregunta_numero]['opcion_1']); ?></label>
          
        <label class="radio">
          <input <?php if (!(strcmp($recuperadas[$pregunta_numero]['seleccion'],"2"))) {echo "checked=\"checked\"";} ?> type="radio" name="opcion" value="2" id="opcion_2" />
          <?php  echo utf8_encode($recuperadas[$pregunta_numero]['opcion_2']); ?></label>
          
        <label class="radio">
          <input <?php if (!(strcmp($recuperadas[$pregunta_numero]['seleccion'],"3"))) {echo "checked=\"checked\"";} ?> type="radio" name="opcion" value="3" id="opcion_3" />
          <?php  echo utf8_encode($recuperadas[$pregunta_numero]['opcion_3']);?></label>
          
        <label class="radio">
          <input <?php if (!(strcmp($recuperadas[$pregunta_numero]['seleccion'],"4"))) {echo "checked=\"checked\"";} ?> type="radio" name="opcion" value="4" id="opcion_4" />
          <?php  echo utf8_encode($recuperadas[$pregunta_numero]['opcion_4']); ?></label>
          
           <input name="id_resultado" type="hidden" value="<?php  echo $recuperadas[$pregunta_numero]['id_resultado'];?>" />
          <input name="fecha_respuesta" type="hidden" value="<?php  echo date('Y-m-d H:i:s');?>" />
          <input name="grabar" type="hidden" value="1" />
          <input name="siguiente" type="hidden" value="<?php echo $siguiente+1; ?>" />
          <input name="correcta" type="hidden" value="<?php echo $recuperadas[$pregunta_numero]['respuesta']; ?>" />
          <input name="espera" type="hidden" value="1" />
            

            
              <div class="pagination_all">
                <div class="pagination"><?php echo $pregunta_numero+1; ?> de 20</div>
                <button name="btnForm" style="margin-top: 12px;" type="button" onclick="validar_radios();" id="btnForm" class="enviar_pregunta" value="Grabar"><img src="<?php echo $base_url;?>img/enviar.png"></button>
              </div>
            
            
        
          

</form>

<!--  <div class="silueta silueta_<?php echo $entrega; ?>" ></div> -->

</div>
<script type="text/javascript">
  function script_add(){
    $('#ModalConcurso').removeClass('alerta');
    $('#ModalConcurso').removeClass('animos');
    $('#ModalConcurso').addClass('t_pregunta_<?php echo $entrega; ?>');
  }
</script>
