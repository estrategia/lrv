<?php require_once('Connections/cnn_avantel.php');?>
<?php include("../demo/funciones.php");?>
<?php 
$j=0; 


include("../demo/temarios.php");

/*

 s� no se han seleccionado preguntas se insertan las pregunras
 s� ya se insertaron preguntas para el usuario y la entrega se verifica s� ya respondi� todas las preguntas de la entrega en curso
 	cuando se respondan todas entonces se le muestra mensaje de ya respond�� o la siguiente entrega s� ya es tiempo
 

*/

# insertar preguntas

echo "<h3>Fecha Acutual: ".$dia_actual."</h3>";
echo "<h3>Entrega Acutual: ".$entrega."</h3>";
echo "entrega_participante:".entrega_participante($_SESSION['MM_ID'],$entrega);
if (entrega_participante($_SESSION['MM_ID'],$entrega)==0) { 

echo "<h3>Verificaci�n de Preguntas insertadas al participante para esta entrega... OK:  ".entrega_participante($_SESSION['MM_ID'],$entrega)."</h3>";

foreach ($seleccion as $valor) {

  $insertSQL = sprintf("INSERT INTO t_resultados (id_participante, id_pregunta, respuesta, opcion, puntaje, entrega, fecha_respuesta) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_SESSION['MM_ID'], "int"),
                       GetSQLValueString($valor['id'], "int"),
                       GetSQLValueString($valor['respuesta'], "int"),
                       GetSQLValueString(NULL, "int"),
					   GetSQLValueString($valor['valor'], "int"),
					   GetSQLValueString($entrega, "int"),
                       GetSQLValueString(date('Y-m-d H:i:s'), "date"));

  mysql_select_db($database_cnn_avantel, $cnn_avantel);
  $Result1 = mysql_query($insertSQL, $cnn_avantel) or die(mysql_error());
}
}
?>
<?php 
echo "<h3>Estado Entrega: ".estado_entrega($_SESSION['MM_ID'],$entrega)."</h3>";
if (estado_entrega($_SESSION['MM_ID'],$entrega)!=1) {
	
	echo "<h1>Puntaje Obtenido en la entrega No.".$entrega.": ".puntaje_entrega($_SESSION['MM_ID'],$entrega)."</h1>";
	
	} else {

	echo "<h3>Recuperaci�n de preguntas grabadas para el concursante en esta entrega</h3>";
	$recuperadas=recuperar_preguntas($_SESSION['MM_ID'],$entrega);
?>


<a data-toggle="modal" href="#myModal_1" class="btn btn-large btn-block btn-warning">Responder Entrega <?php echo $entrega; ?></a>


<?php
foreach ($recuperadas as $valor) {
    $j++;

?>
<form id="form1_<?php echo $j; ?>" name="form1_<?php echo $j; ?>" method="post" action="../demo/respuesta_e.php">

<div id="myModal_<?php echo $j; ?>"tabindex="-1" class="modal hide fade"  role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="height:400px;">
 
 
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
    <h3 id="myModalLabel"><?php  echo $valor['tema'];?> <small>[<?php echo $valor['valor']; ?>]</small></h3>
  </div>
  <div class="modal-body">
    <p>
<h3><?php echo $j; ?>. <?php  echo $valor['pregunta'];?></h3>
    
        <label class="radio">
          <input <?php if (!(strcmp($valor['seleccion'],"1"))) {echo "checked=\"checked\"";} ?> type="radio" name="opcion" value="1" id="opcion_1" />
          <?php  echo $valor['opcion_1'];?></label>
          
        <label class="radio">
          <input <?php if (!(strcmp($valor['seleccion'],"2"))) {echo "checked=\"checked\"";} ?> type="radio" name="opcion" value="2" id="opcion_2" />
          <?php  echo $valor['opcion_2'];?></label>
          
        <label class="radio">
          <input <?php if (!(strcmp($valor['seleccion'],"3"))) {echo "checked=\"checked\"";} ?> type="radio" name="opcion" value="3" id="opcion_3" />
          <?php  echo $valor['opcion_3'];?></label>
          
        <label class="radio">
          <input <?php if (!(strcmp($valor['seleccion'],"4"))) {echo "checked=\"checked\"";} ?> type="radio" name="opcion" value="4" id="opcion_4" />
          <?php  echo $valor['opcion_4'];?></label>
          
          <input name="id_resultado" type="hidden" value="<?php  echo $valor['id_resultado'];?>" />
          <input name="fecha_respuesta" type="hidden" value="<?php  echo date('Y-m-d H:i:s');?>" />
          <input name="siguiente" type="hidden" value="<?php  echo $j+1;?>" />
          
  </p>    
  </div>
  <div class="modal-footer">
    <button class="btn" data-dismiss="modal" aria-hidden="true">Anterior</button>
    <input name="btnForm" type="submit" id="btnForm" value="Grabar"  class="btn btn-primary btn-large"/>
      
    <a data-toggle="modal" href="#myModal_<?php echo $j+1; ?>" class="btn btn-primary btn-large">Siguiente Pregunta</a>
    <button type="button" name="deleteButton" id="deleteButton">Launch modal</button>

    
  </div>
</div>
</form>
<?php } ?>
<?php } ?>
<div class="well">

<p><br />
</p>
<ol>
  <li>
    <p>El concurso se realizar&aacute;  	enmarcado en los 70 a&ntilde;os de Carvajal.</p>
  </li>
</ol>
<p><br />
</p>
<ol start="2">
  <li>
    <p>Descripci&oacute;n del Concurso:</p>
  </li>
</ol>
<p><br />
</p>
<ol>
  <ol type="a">
    <li>
      <p>Encuesta peri&oacute;dica acerca de un  		temario</p>
    </li>
  </ol>
</ol>
<p><br />
</p>
<ol>
  <ol type="a" start="2">
    <li>
      <p><a name="_GoBack" id="_GoBack"></a>Ser&aacute; 6  		temarios:</p>
      <ol type="i">
        <li>
          <p>Cultura ciudadana</p>
        </li>
        <li>
          <p>Gobierno</p>
        </li>
        <li>
          <p> Historia de Carvajal</p>
        </li>
        <li>
          <p>Cooperativismo</p>
        </li>
        <li>
          <p>Cooperativa</p>
        </li>
        <li>
          <p>Tema Junior</p>
        </li>
      </ol>
    </li>
  </ol>
</ol>
<p><br />
</p>
<ol>
  <ol type="a" start="3">
    <li>
      <p>Se tendr&aacute; una bolsa de 100  		preguntas. Se lanza una primera bolsa de 20 preguntas: a cada  		participante se lanzan 7, las cuales deben ser aleatorias. En lo  		posible todas las combinaciones sean diferentes. </p>
    </li>
  </ol>
</ol>
<p><br />
</p>
<ol>
  <ol type="a">
    <ol type="i">
      <li>
        <p>Se tienen 15 d&iacute;as para  			contestar </p>
      </li>
    </ol>
  </ol>
</ol>
<p><br />
</p>
<ol>
  <ol type="a">
    <ol type="i" start="2">
      <li>
        <p>Las preguntas tienen diferentes  			puntaje de acuerdo con  la dificultad: las preguntas sencillas van  			a tener 1 puntos, las medias es de 3 puntos, y las dificultosas 5  			puntos.</p>
      </li>
    </ol>
  </ol>
</ol>
<p><br />
</p>
<ol>
  <ol type="a">
    <ol type="i" start="3">
      <li>
        <p>Se deben tener en cuenta el  			lanzamiento de la siguiente manera:</p>
      </li>
    </ol>
  </ol>
</ol>
<p><br />
</p>
<dl>
  <dl>
    <dl>
      <dl>
        <dd>
          <table width="487" cellpadding="7" cellspacing="0">
            <col width="59" />
            <col width="61" />
            <col width="50" />
            <col width="65" />
            <col width="79" />
            <col width="89" />
            <tr valign="top">
              <td width="59"><p align="center">Entregas</p></td>
              <td width="61"><p align="center">Sencillas (1)</p></td>
              <td width="50"><p align="center">Medias (3)</p></td>
              <td width="65"><p align="center">Dif&iacute;ciles</p>
                <p align="center">(5)</p></td>
              <td width="79"><p align="center">S&uacute;per dif&iacute;cil (7)</p></td>
              <td width="89"><p align="center">Total</p></td>
            </tr>
            <tr valign="top">
              <td width="59"><p align="center">1</p></td>
              <td width="61"><p align="center">5</p></td>
              <td width="50"><p align="center">2</p></td>
              <td width="65"><p align="center">0</p></td>
              <td width="79"><p align="center"><br />
              </p></td>
              <td width="89"><p align="center">11</p></td>
            </tr>
            <tr valign="top">
              <td width="59"><p align="center">2</p></td>
              <td width="61"><p align="center">4</p></td>
              <td width="50"><p align="center">3</p></td>
              <td width="65"><p align="center">0</p></td>
              <td width="79"><p align="center"><br />
              </p></td>
              <td width="89"><p align="center">13</p></td>
            </tr>
            <tr valign="top">
              <td width="59"><p align="center">3</p></td>
              <td width="61"><p align="center">3</p></td>
              <td width="50"><p align="center">3</p></td>
              <td width="65"><p align="center">2</p></td>
              <td width="79"><p align="center"><br />
              </p></td>
              <td width="89"><p align="center">22</p></td>
            </tr>
            <tr valign="top">
              <td width="59"><p align="center">4</p></td>
              <td width="61"><p align="center">2</p></td>
              <td width="50"><p align="center">2</p></td>
              <td width="65"><p align="center">3</p></td>
              <td width="79"><p align="center"><br />
              </p></td>
              <td width="89"><p align="center">23</p></td>
            </tr>
            <tr valign="top">
              <td width="59"><p align="center">5</p></td>
              <td width="61"><p align="center">1</p></td>
              <td width="50"><p align="center">1</p></td>
              <td width="65"><p align="center">4</p></td>
              <td width="79"><p align="center">1</p></td>
              <td width="89"><p align="center">31</p></td>
            </tr>
            <tr valign="top">
              <td colspan="5" width="370"><p align="center">Total Puntos</p></td>
              <td width="89"><p align="center">100</p></td>
            </tr>
          </table>
        </dd>
      </dl>
    </dl>
  </dl>
</dl>
<p><br />
</p>
<ol>
  <ol type="a" start="4">
    <li>
      <p>El panel del administrador debe  		mostrar los resultados por ranking de puntos general, y tambi&eacute;n  		por categor&iacute;a (temario).</p>
    </li>
  </ol>
</ol>
<p><br />
</p>
<ol>
  <ol type="a" start="5">
    <li>
      <p>El sistema debe contemplar env&iacute;o  		masivo.</p>
    </li>
  </ol>
</ol>
<p><br />
</p>
<ol>
  <ol type="a" start="6">
    <li>
      <p>EISO se encargar&aacute; de la compra  		del hosting y el dominio.</p>
    </li>
  </ol>
</ol>
<p><br />
</p>
<ol>
  <ol type="a" start="7">
    <li>
      <p>Inscripciones todo agosto. Y  		lanzar el primer combo del 1 al 15 de septiembre.</p>
    </li>
  </ol>
</ol>
<p><br />
</p>
</div>
