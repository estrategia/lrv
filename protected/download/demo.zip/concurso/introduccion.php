<?php
if (!isset($base_url)) {
  $base_url="/concurso/";
}
 include("temarios.php");
switch ($entrega) {
	case 1: $text_temario="Villa deportes 10mil millas a ganar por una lavadora";
			$img_temario="deportes/villa_deportes.png";
			$lat_left="deportes/villa_deportes2.png";
			$lat_right="deportes/villa_deportes3.png";
		# code...
		break;
	case 2: $text_temario="Ciudad cultura 20mil millas a ganar por un TV de 32";
			$img_temario="cultura/ciudad_cultura1.png";
			$lat_left="cultura/ciudad_cultura2.png";
			$lat_right="cultura/ciudad_cultura3.png";
		# code...
		break;
	case 3: $text_temario="Parque nuestra empresa 30mil millas a ganar por una nevera";
			$img_temario="carvajal/ParqueNuestraEmpresa.png";
			$lat_left="carvajal/empresa_nevera.png";
			$lat_right="carvajal/empresa_carretera.png";
		# code...
		break;	
	case 4: $text_temario="Mi cooperativa DC 40mil millas a ganar por un comedor para 4 personas";
			$img_temario="cooperativa/MiCooperativa.png";
			$lat_left="cooperativa/coop_comedor.png";
			$lat_right="cooperativa/coop_carretera.png";
		# code...
		break;
}
 ?>
 <div class="conte_introduccion">
 	<img src="img/intro_etapa.jpg">
<div class="group_button">

<form action="../demo/cuestionario.php" method="post" name="frmInicio">
<input name="siguiente" type="hidden" value="1">
<button style="background-color: transparent; border: none;"><img src="img/jugar_ya.png"></button>
</form>

<!-- <a href="../demo/alerta.php" datanamehref="hrefajax"><img src="img/jugar_ya.png"></a>
<a href="#" datanamehref="hrefajax"><img src="img/jugar_ya.png"></a> -->
<form action="cuestionario.php" method="post" name="frmInicio">
<input name="siguiente" type="hidden" value="1">
<button style="background-color: transparent; border: none;"><img src="img/empieza_a_jugar.png"></button>
</form>
</div>
</div>
 <img src="<?php echo $base_url; ?>img/concurso/bottom_contenedor_blanco.png" class="bottom_blanco_general img-responsive  visible-xs">




<script type="text/javascript">
  function script_add(){
  	$('#ModalConcurso').removeClass('datos_participante');
	$('#ModalConcurso').removeClass('t_puntaje');
    $('#ModalConcurso').addClass('introduccion');
    $('#ModalConcurso').addClass('intro_<?php echo $entrega; ?>');
  }
</script>
