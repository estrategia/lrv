<?php 

$timer=(tiempo_restante($_SESSION['MM_Username'],$entrega));

if ($timer[0]=='999') {

	$fecha_cierre_prueba=date('Y/m/d H:i:s',strtotime('+2 hours'));

	} else {

	$fecha_cierre_prueba=date('Y/m/d H:i:s',strtotime($timer[0]));

}

$hora_cierre_prueba=date('H:i:s',strtotime($timer[1]));

$segundos_restantes=$timer[2];

?>





<div id="cronometro_parent">

<style type="text/css">

      br { clear: both; }

      .cntSeparator {

        font-size: 54px;

        margin: 10px 7px;

        color: #000;

      }

      .desc { margin: 7px 3px; }

      .desc div {

        float: left;

        font-family: Arial;

        width: 70px;

        margin-right: 65px;

        font-size: 13px;

        font-weight: bold;

        color: #000;

      }

    </style>

<script type="text/javascript">

   

        $('#counter').county({

             endDateTime: new Date('<?php echo $fecha_cierre_prueba; ?>'),

              reflection: false,

               animation: 'scroll',

                theme: 'red' 

        });

</script>

<div class="conteo">

  <img class="img-responsive img_tiempo" src="img/pregunta_errada.png"><strong class="str_1">tienes que terminar esta etapa en...</strong><div id="counter" class="contador_class"></div>

  </div>

 

    </div>

 

