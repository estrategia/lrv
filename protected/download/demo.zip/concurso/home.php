<?php
$ano_hoy=date('Y');
$mes_hoy=date('m');
$dia_hoy=date('d');
$hora_hoy=date('H',strtotime("+2 hours"));
$min_hoy=date('i');
$seg_hoy=date('s');
?>
<style type="text/css">
#count {
    border-style: ridge;    /* options are none, dotted, dashed, solid, double, groove, ridge, inset, outset */
    border-width: 2px;
    border-color: #666666;  /* change color of the border using the hexadecimal color codes for HTML */
    padding: 4px;           /* change the spacing between the timer and the border */
    text-align: center; 
    font-family: Arial; 
    font-size: 22px;        /* change the size of the font */
    font-weight: normal;    /* options are normal, bold, bolder, lighter */
    font-style: normal;     /* options are normal or italic */
    color: #FFFFFF;    /* change color using the hexadecimal color codes for HTML */
    background-color: #222222;    /* change the background color using the hex color codes for HTML */
    margin: 0px auto;
    position: relative;    /* leave as "relative" to keep timer centered on your page, or change to "absolute" then change the values of the "top" and "left" properties to position the timer */
    top: 0px;        /* change to position the timer */
    left: 0px;       /* change to position the timer; delete this property and it's value to keep timer centered on page */
    width: 582px;
    height: auto;
}
</style>

<script type="text/javascript">

/*
Count down until any date script-
By JavaScript Kit (www.javascriptkit.com)
Over 200+ free scripts here!
Modified by Robert M. Kuhnhenn, D.O. 
on 5/30/2006 to count down to a specific date AND time,
on 10/20/2007 to a new format, and 1/10/2010 to include
time zone offset.
*/

/*  Change the items below to create your countdown target date and announcement once the target date and time are reached.  */
var current="Termin� tu tiempo!!!";    //-->enter what you want the script to display when the target date and time are reached, limit to 20 characters
var year=<?php echo $ano_hoy; ?>;    //-->Enter the count down target date YEAR
var month=<?php echo $mes_hoy; ?>;      //-->Enter the count down target date MONTH
var day=<?php echo $dia_hoy; ?>;       //-->Enter the count down target date DAY
var hour=<?php echo $hora_hoy; ?>;      //-->Enter the count down target date HOUR (24 hour clock)
var minute=<?php echo $min_hoy; ?>;    //-->Enter the count down target date MINUTE
var tz=-5;        //-->Offset for your timezone in hours from UTC (see http://wwp.greenwichmeantime.com/index.htm to find the timezone offset for your location)

//-->    DO NOT CHANGE THE CODE BELOW!    <--
var montharray=new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");

function countdown(yr,m,d,hr,min){
theyear=yr;themonth=m;theday=d;thehour=hr;theminute=min;
    var today=new Date();
    var todayy=today.getYear();
    if (todayy < 1000) {todayy+=1900;}
    var todaym=today.getMonth();
    var todayd=today.getDate();
    var todayh=today.getHours();
    var todaymin=today.getMinutes();
    var todaysec=today.getSeconds();
    var todaystring1=montharray[todaym]+" "+todayd+", "+todayy+" "+todayh+":"+todaymin+":"+todaysec;
    var todaystring=Date.parse(todaystring1)+(tz*1000*60*60);
    var futurestring1=(montharray[m-1]+" "+d+", "+yr+" "+hr+":"+min);
    var futurestring=Date.parse(futurestring1)-(today.getTimezoneOffset()*(1000*60));
    var dd=futurestring-todaystring;
    var dday=Math.floor(dd/(60*60*1000*24)*1);
    var dhour=Math.floor((dd%(60*60*1000*24))/(60*60*1000)*1);
    var dmin=Math.floor(((dd%(60*60*1000*24))%(60*60*1000))/(60*1000)*1);
    var dsec=Math.floor((((dd%(60*60*1000*24))%(60*60*1000))%(60*1000))/1000*1);
    if(dday<=0&&dhour<=0&&dmin<=0&&dsec<=0){
        document.getElementById('count').innerHTML=current;
        return;
    }
    else {
        document.getElementById('count').innerHTML=+dday+ " d�as, "+dhour+" horas, "+dmin+" minutos, y "+dsec+" segundos";
        setTimeout("countdown(theyear,themonth,theday,thehour,theminute)",1000);
    }
}
</script>

    


      
      
      <p>Alerta!!! <?php echo $_SESSION['MM_Nombre']; ?> y Familia. Su misi�n si deciden aceptarla es responder CORRECTAMENTE las siguientes 9 preguntas. Recuerden que este juego se cerrar� en 2 horas (<?php echo date("h:i a",strtotime("+2 hours"));?>), a partir de este momento  � A JUGAR!!!! <span id="count"></span>
</p>
contador
<span id="countdown"></span>
      
      <a href="index.php?opcion=cuestionario" class="btn btn-large btn-block btn-primary" >JUGAR</a>
      
      
      
      <h2>Ranking</h2>
      