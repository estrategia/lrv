<?php require_once('Connections/cnn_avantel.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsEmpresa = "SELECT DISTINCT empresa FROM t_participantes ORDER BY empresa";
$rsEmpresa = mysql_query($query_rsEmpresa, $cnn_avantel) or die(mysql_error());
$row_rsEmpresa = mysql_fetch_assoc($rsEmpresa);
$totalRows_rsEmpresa = mysql_num_rows($rsEmpresa);

mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsDistritos = "select distinct distrito from t_participantes order by distrito";
$rsDistritos = mysql_query($query_rsDistritos, $cnn_avantel) or die(mysql_error());
$row_rsDistritos = mysql_fetch_assoc($rsDistritos);
$totalRows_rsDistritos = mysql_num_rows($rsDistritos);

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
 echo  $insertSQL = sprintf("INSERT INTO t_participantes (id_participante, usuario, clave, nombres, apellidos, apellido_1, apellido_2, nombre_1, nombre_2, distrito, empresa, email) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['id_participante'], "int"),
                       GetSQLValueString($_POST['id_participante'], "text"),
                       GetSQLValueString(substr($_POST['id_participante'],-4), "text"),
                       GetSQLValueString($_POST['nombres'], "text"),
                       GetSQLValueString($_POST['apellidos'], "text"),
                       GetSQLValueString($_POST['apellido_1'], "text"),
                       GetSQLValueString($_POST['apellido_2'], "text"),
                       GetSQLValueString($_POST['nombre_1'], "text"),
                       GetSQLValueString($_POST['nombre_2'], "text"),
                       GetSQLValueString($_POST['distrito'], "text"),
                       GetSQLValueString($_POST['empresa'], "text"),
                       GetSQLValueString($_POST['email'], "text"));

  mysql_select_db($database_cnn_avantel, $cnn_avantel);
  $Result1 = mysql_query($insertSQL, $cnn_avantel) or die(mysql_error());

  $insertGoTo = "../comasy/index.php?opcion=participantes";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<form action="../demo/<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Identificaci&oacute;n:</td>
      <td><input type="text" name="id_participante" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Nombres:</td>
      <td><input type="text" name="nombres" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Apellidos:</td>
      <td><input type="text" name="apellidos" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Apellido_1:</td>
      <td><input type="text" name="apellido_1" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Apellido_2:</td>
      <td><input type="text" name="apellido_2" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Nombre_1:</td>
      <td><input type="text" name="nombre_1" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Nombre_2:</td>
      <td><input type="text" name="nombre_2" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Distrito:</td>
      <td><select name="distrito" id="distrito">
        <?php
do {  
?>
        <option value="<?php echo $row_rsDistritos['distrito']?>"><?php echo $row_rsDistritos['distrito']?></option>
        <?php
} while ($row_rsDistritos = mysql_fetch_assoc($rsDistritos));
  $rows = mysql_num_rows($rsDistritos);
  if($rows > 0) {
      mysql_data_seek($rsDistritos, 0);
	  $row_rsDistritos = mysql_fetch_assoc($rsDistritos);
  }
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Empresa:</td>
      <td> <select name="empresa" id="empresa">
        <?php
do {  
?>
        <option value="<?php echo $row_rsEmpresa['empresa']?>"><?php echo $row_rsEmpresa['empresa']?></option>
        <?php
} while ($row_rsEmpresa = mysql_fetch_assoc($rsEmpresa));
  $rows = mysql_num_rows($rsEmpresa);
  if($rows > 0) {
      mysql_data_seek($rsEmpresa, 0);
	  $row_rsEmpresa = mysql_fetch_assoc($rsEmpresa);
  }
?>
      </select>    </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Email:</td>
      <td><input type="text" name="email" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Adicionar Participante" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1" />
</form>

</body>
</html><?php
mysql_free_result($rsEmpresa);

mysql_free_result($rsDistritos);
?>
