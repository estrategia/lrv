<?php require_once('Connections/cnn_avantel.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_cnn_avantel, $cnn_avantel);
$query_rsTemarios = "SELECT * FROM t_temarios";
$rsTemarios = mysql_query($query_rsTemarios, $cnn_avantel) or die(mysql_error());
$row_rsTemarios = mysql_fetch_assoc($rsTemarios);
$totalRows_rsTemarios = mysql_num_rows($rsTemarios);

do { 
	$temarios[$row_rsTemarios['id_temario']]=array('tema'=>$row_rsTemarios['temario'],'inicio'=>$row_rsTemarios['fecha_lanzamiento'],'fin'=>$row_rsTemarios['fecha_cierre']);
  } while ($row_rsTemarios = mysql_fetch_assoc($rsTemarios));

// reset the recordset after a repeat region
mysql_data_seek($rsTemarios, 0);
// get the first row from the recordset
$row_rsTemarios = mysql_fetch_assoc($rsTemarios);

include("../concurso/funciones.php");

$dia_actual=date('Y-m-d H:i:s');

if ($dia_actual>=$temarios[1]['inicio']." 00:00:00" && $dia_actual<=$temarios[1]['fin']." 23:59:59") {
	$entrega=1; $millas=10*1000;
	$seleccion=seleccion_grupo(1); # 9 preguntas del temario 1
	}
if ($dia_actual>=$temarios[2]['inicio']." 00:00:00" && $dia_actual<=$temarios[2]['fin']." 23:59:59") {
	$entrega=2; $millas=10*3000;
	$seleccion=seleccion_grupo(2); # 9 preguntas del temario 2
	}
if ($dia_actual>=$temarios[3]['inicio']." 00:00:00" && $dia_actual<=$temarios[3]['fin']." 23:59:59") {
	$entrega=3; $millas=10*2000;
	$seleccion=seleccion_grupo(3); # 9 preguntas del temario 3
	}
if ($dia_actual>=$temarios[4]['inicio']." 00:00:00" && $dia_actual<=$temarios[4]['fin']." 23:59:59") {
	$entrega=4; $millas=10*4000;
	$seleccion=seleccion_grupo(4); # 9 preguntas del temario 4
	}
	 $nombre_temario=$temarios[$entrega]['tema'];

mysql_free_result($rsTemarios);
?>
