<?php 
$timer=(tiempo_restante($_SESSION['MM_Username'],$entrega));
$fecha_cierre_prueba=date('Y/m/d H:i:s',strtotime($timer[0]));
$hora_cierre_prueba=date('H:i:s',strtotime($timer[1]));
$segundos_restantes=$timer[2];
if ($segundos_restantes<=0) { 
 ?>
 El tiempo de cierre de la prueba anterior fue: <?php echo $fecha_cierre_prueba;  ?>
 <?php
} else {
  if (estado_entrega($_SESSION['MM_ID'],$entrega)==1) {
?>
<script type="text/javascript">
     /* $(function(){
        $('#counter').countdown({
          image: 'img/digits.png',
          startTime: '<?php echo $timer[1]; ?>',
          timerEnd: function(){ alert('Termin&oacute; la Prueba!'); },
          digitWidth: 25,
          digitHeight: 36,
          digitImages: 4,
          format: 'hh:mm:ss'
        });
      });*/<?php 
                $total_hora= $hora_cierre_prueba;
                $fecha=date('Y/m/d');
            ?>
        $('#counter').county({
             endDateTime: new Date('<?php echo $fecha_cierre_prueba; ?>'),
              reflection: false,
               animation: 'scroll',
                theme: 'red' 
        });
        
         
      
  </script>
    <style type="text/css">
      br { clear: both; }
      .cntSeparator {
        font-size: 54px;
        margin: 10px 7px;
        color: #000;
      }
      .desc { margin: 7px 3px; }
      .desc div {
        float: left;
        font-family: Arial;
        width: 70px;
        margin-right: 65px;
        font-size: 13px;
        font-weight: bold;
        color: #000;
      }
    </style>
  <div class="conteo">
  <div id="counter"></div>
 
  </div>
<?php } }  ?>
